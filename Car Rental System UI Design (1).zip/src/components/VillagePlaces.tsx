import React from 'react';
import { 
  Building2, 
  School, 
  Store, 
  Hospital, 
  Stethoscope, 
  Wrench, 
  GraduationCap, 
  MapPin,
  Sparkles
} from 'lucide-react';

const places = [
  { icon: Building2, title: 'المساجد', description: 'بيوت الله في قريتنا، مراكز للعبادة والتواصل', color: 'from-green-500 to-emerald-600' },
  { icon: School, title: 'المدارس', description: 'منارات العلم والمعرفة لأبنائنا', color: 'from-blue-500 to-cyan-600' },
  { icon: Store, title: 'المحلات التجارية', description: 'متاجر توفر احتياجات أهل القرية اليومية', color: 'from-orange-500 to-amber-600' },
  { icon: Hospital, title: 'الصيدليات', description: 'رعاية صحية وأدوية لسكان القرية', color: 'from-red-500 to-rose-600' },
  { icon: Stethoscope, title: 'الأطباء', description: 'أطباء وممرضون يخدمون المجتمع', color: 'from-teal-500 to-cyan-600' },
  { icon: Wrench, title: 'الحرفيون', description: 'نجارون وحدادون وبناؤون مهرة', color: 'from-gray-600 to-slate-700' },
  { icon: GraduationCap, title: 'المعلمون', description: 'معلمون متفانون في تعليم الأجيال', color: 'from-purple-500 to-violet-600' },
  { icon: MapPin, title: 'الأماكن المشهورة', description: 'معالم وساحات يجتمع فيها الناس', color: 'from-pink-500 to-rose-600' }
];

export default function VillagePlaces() {
  return (
    <section className="py-24 px-8 bg-gradient-to-br from-green-50/50 to-amber-50/50">
      <div className="max-w-7xl mx-auto">
        {/* Section title */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-4">
            <MapPin className="w-8 h-8 text-green-600" />
            <h2 className="text-4xl text-gray-800">أماكن ومعالم القرية</h2>
            <MapPin className="w-8 h-8 text-green-600" />
          </div>
          <p className="text-xl text-gray-600 mt-4">
            تعرف على الأماكن المهمة والخدمات المتوفرة في قريتنا
          </p>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-green-500 to-transparent mx-auto mt-4"></div>
        </div>

        {/* Places grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {places.map((place, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden hover:-translate-y-2 border border-gray-100"
            >
              <div className={`h-3 bg-gradient-to-r ${place.color}`}></div>
              <div className="p-6">
                <div className={`inline-flex p-4 bg-gradient-to-br ${place.color} rounded-2xl shadow-md mb-4 group-hover:scale-110 transition-transform`}>
                  <place.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl text-gray-800 mb-2">{place.title}</h3>
                <p className="text-gray-600 leading-relaxed">{place.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Engineers and Farmers section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
          <div className="bg-gradient-to-br from-indigo-100 to-blue-100 rounded-2xl shadow-lg p-8 border border-indigo-200">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-4 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-2xl shadow-md">
                <Sparkles className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl text-gray-800">المهندسون</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">
              مهندسون في مختلف المجالات يساهمون في تطوير القرية وتحديث بنيتها التحتية
            </p>
          </div>

          <div className="bg-gradient-to-br from-green-100 to-emerald-100 rounded-2xl shadow-lg p-8 border border-green-200">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-4 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl shadow-md">
                <TreePine className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl text-gray-800">المزارعون</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">
              مزارعون مجتهدون يعتنون بالأرض ويوفرون المنتجات الزراعية الطازجة للقرية
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function TreePine(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 3L8 9h8l-4-6z" />
      <path d="M9 9L6 14h12l-3-5" />
      <path d="M7 14L4 19h16l-3-5" />
      <path d="M12 19v3" />
    </svg>
  );
}