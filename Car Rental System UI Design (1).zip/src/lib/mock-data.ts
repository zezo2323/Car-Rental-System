// Mock data for the car rental system

export interface Car {
  id: string;
  name: string;
  brand: string;
  model: string;
  year: number;
  pricePerDay: number;
  category: 'sedan' | 'suv' | 'sports' | 'luxury' | 'electric';
  image: string;
  available: boolean;
  features: string[];
  seats: number;
  transmission: 'automatic' | 'manual';
  fuelType: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'admin' | 'user';
  phone?: string;
  avatar?: string;
}

export interface Rental {
  id: string;
  carId: string;
  userId: string;
  startDate: string;
  endDate: string;
  totalDays: number;
  totalAmount: number;
  status: 'active' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  carId: string;
  rating: number;
  comment: string;
  date: string;
  adminReply?: string;
}

export const mockCars: Car[] = [
  {
    id: '1',
    name: 'BMW 5 Series',
    brand: 'BMW',
    model: '530i',
    year: 2024,
    pricePerDay: 150,
    category: 'luxury',
    image: 'https://images.unsplash.com/photo-1669577569343-f599ffa343d5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBjYXIlMjBCTVd8ZW58MXx8fHwxNzY1MDA2NTM1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
    features: ['Leather Seats', 'Navigation', 'Sunroof', 'Bluetooth'],
    seats: 5,
    transmission: 'automatic',
    fuelType: 'Petrol',
  },
  {
    id: '2',
    name: 'Mercedes-Benz E-Class',
    brand: 'Mercedes-Benz',
    model: 'E300',
    year: 2024,
    pricePerDay: 180,
    category: 'luxury',
    image: 'https://images.unsplash.com/photo-1722088354078-89415751076c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxNZXJjZWRlcyUyMHNlZGFuJTIwY2FyfGVufDF8fHx8MTc2NTAwNjUzNXww&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
    features: ['Massage Seats', 'Premium Sound', 'Ambient Lighting', 'Autopilot'],
    seats: 5,
    transmission: 'automatic',
    fuelType: 'Petrol',
  },
  {
    id: '3',
    name: 'Audi RS7',
    brand: 'Audi',
    model: 'RS7',
    year: 2024,
    pricePerDay: 250,
    category: 'sports',
    image: 'https://images.unsplash.com/photo-1667034864688-3ca5addf1e51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBdWRpJTIwc3BvcnRzJTIwY2FyfGVufDF8fHx8MTc2NDkzMDc5M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    available: false,
    features: ['Sports Mode', 'Racing Seats', 'Performance Brakes', 'Spoiler'],
    seats: 4,
    transmission: 'automatic',
    fuelType: 'Petrol',
  },
  {
    id: '4',
    name: 'Tesla Model S',
    brand: 'Tesla',
    model: 'Model S Plaid',
    year: 2024,
    pricePerDay: 200,
    category: 'electric',
    image: 'https://images.unsplash.com/photo-1719772692993-933047b8ea4a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxUZXNsYSUyMGVsZWN0cmljJTIwY2FyfGVufDF8fHx8MTc2NDkxMDg0Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
    features: ['Autopilot', 'Large Screen', 'Fast Charging', 'Long Range'],
    seats: 5,
    transmission: 'automatic',
    fuelType: 'Electric',
  },
  {
    id: '5',
    name: 'Range Rover Sport',
    brand: 'Land Rover',
    model: 'Range Rover Sport',
    year: 2024,
    pricePerDay: 220,
    category: 'suv',
    image: 'https://images.unsplash.com/photo-1506616995931-556bc0c90c16?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxSYW5nZSUyMFJvdmVyJTIwU1VWfGVufDF8fHx8MTc2NDkxMDg0NXww&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
    features: ['4WD', 'Terrain Response', 'Panoramic Roof', 'Premium Audio'],
    seats: 7,
    transmission: 'automatic',
    fuelType: 'Diesel',
  },
  {
    id: '6',
    name: 'Porsche 911',
    brand: 'Porsche',
    model: '911 Carrera',
    year: 2024,
    pricePerDay: 300,
    category: 'sports',
    image: 'https://images.unsplash.com/photo-1641209624342-e20d49275892?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxQb3JzY2hlJTIwc3BvcnRzJTIwY2FyfGVufDF8fHx8MTc2NTAwNTUyOXww&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
    features: ['Sport Chrono', 'Carbon Fiber', 'Racing Package', 'Premium Interior'],
    seats: 2,
    transmission: 'automatic',
    fuelType: 'Petrol',
  },
  {
    id: '7',
    name: 'Toyota Camry',
    brand: 'Toyota',
    model: 'Camry',
    year: 2024,
    pricePerDay: 80,
    category: 'sedan',
    image: 'https://images.unsplash.com/photo-1648197323414-4255ea82d86b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxUb3lvdGElMjBzZWRhbiUyMGNhcnxlbnwxfHx8fDE3NjQ5MTQ4Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
    features: ['Fuel Efficient', 'Safety Package', 'Apple CarPlay', 'Backup Camera'],
    seats: 5,
    transmission: 'automatic',
    fuelType: 'Hybrid',
  },
  {
    id: '8',
    name: 'Honda Civic',
    brand: 'Honda',
    model: 'Civic',
    year: 2024,
    pricePerDay: 70,
    category: 'sedan',
    image: 'https://images.unsplash.com/photo-1761231448758-d981d9cc88c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxIb25kYSUyMGNvbXBhY3QlMjBjYXJ8ZW58MXx8fHwxNzY1MDA2NTM3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    available: true,
    features: ['Lane Assist', 'Cruise Control', 'Android Auto', 'Bluetooth'],
    seats: 5,
    transmission: 'automatic',
    fuelType: 'Petrol',
  },
];

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@carrental.com',
    password: 'admin123',
    role: 'admin',
    phone: '+1234567890',
  },
  {
    id: '2',
    name: 'John Doe',
    email: 'user@example.com',
    password: 'user123',
    role: 'user',
    phone: '+1987654321',
  },
  {
    id: '3',
    name: 'Sarah Johnson',
    email: 'sarah@example.com',
    password: 'user123',
    role: 'user',
    phone: '+1122334455',
  },
];

export const mockRentals: Rental[] = [
  {
    id: 'R001',
    carId: '3',
    userId: '2',
    startDate: '2024-12-01',
    endDate: '2024-12-10',
    totalDays: 9,
    totalAmount: 2250,
    status: 'active',
    createdAt: '2024-11-25',
  },
  {
    id: 'R002',
    carId: '1',
    userId: '3',
    startDate: '2024-12-05',
    endDate: '2024-12-08',
    totalDays: 3,
    totalAmount: 450,
    status: 'active',
    createdAt: '2024-12-01',
  },
];

export const mockComments: Comment[] = [
  {
    id: 'C001',
    userId: '2',
    userName: 'John Doe',
    carId: '1',
    rating: 5,
    comment: 'Amazing car! Very comfortable and smooth ride. Highly recommend!',
    date: '2024-11-20',
    adminReply: 'Thank you for your feedback! We\'re glad you enjoyed the BMW 5 Series.',
  },
  {
    id: 'C002',
    userId: '3',
    userName: 'Sarah Johnson',
    carId: '2',
    rating: 4,
    comment: 'Great luxury car, but a bit pricey. Worth it for special occasions.',
    date: '2024-11-22',
  },
  {
    id: 'C003',
    userId: '2',
    userName: 'John Doe',
    carId: '7',
    rating: 5,
    comment: 'Perfect for daily use. Fuel efficient and reliable.',
    date: '2024-11-25',
    adminReply: 'Thank you! The Camry is indeed one of our most popular choices.',
  },
];
