export interface Car {
  id: string;
  name: string;
  brand: string;
  category: 'sedan' | 'suv' | 'sports' | 'luxury' | 'economy';
  image: string;
  pricePerDay: number;
  seats: number;
  transmission: 'automatic' | 'manual';
  fuel: 'بنزين' | 'ديزل' | 'كهربائية' | 'هايبرد';
  features: string[];
  available: boolean;
  year: number;
  plateNumber: string;
}

export interface Rental {
  id: string;
  carId: string;
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  startDate: string;
  endDate: string;
  pickupTime: string;
  returnTime: string;
  totalDays: number;
  pricePerDay: number;
  subtotal: number;
  tax: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'ongoing' | 'completed' | 'cancelled';
  createdAt: string;
  paymentMethod: 'cash' | 'card' | 'transfer';
}

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'admin' | 'user';
  phone: string;
  address?: string;
  licenseNumber?: string;
  avatar?: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  carId?: string;
  rating: number;
  comment: string;
  date: string;
  reply?: {
    text: string;
    date: string;
    adminName: string;
  };
}

export interface Stats {
  totalCars: number;
  availableCars: number;
  rentedCars: number;
  totalRevenue: number;
  monthlyRevenue: number;
  activeRentals: number;
  totalUsers: number;
  pendingBookings: number;
}
