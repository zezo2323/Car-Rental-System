import React from 'react';
import { motion } from 'motion/react';
import { Users, Briefcase } from 'lucide-react';

const professions = [
  { name: 'أحمد المزارع', profession: 'مزارع عنب', icon: '🌾', color: 'from-green-500 to-emerald-600' },
  { name: 'فاطمة المعلمة', profession: 'معلمة لغة عربية', icon: '📚', color: 'from-blue-500 to-cyan-600' },
  { name: 'خالد النجار', profession: 'نجار وحرفي', icon: '🔨', color: 'from-amber-500 to-orange-600' },
  { name: 'ليلى الطبيبة', profession: 'طبيبة عامة', icon: '⚕️', color: 'from-red-500 to-rose-600' },
  { name: 'محمود المهندس', profession: 'مهندس مدني', icon: '🏗️', color: 'from-indigo-500 to-purple-600' },
  { name: 'نورة الصيدلانية', profession: 'صيدلانية', icon: '💊', color: 'from-teal-500 to-cyan-600' },
  { name: 'سعيد الحداد', profession: 'حداد ماهر', icon: '⚒️', color: 'from-gray-600 to-slate-700' },
  { name: 'مريم الخياطة', profession: 'خياطة وتطريز', icon: '✂️', color: 'from-pink-500 to-rose-600' },
];

export default function Community() {
  return (
    <section id="community" className="py-32 px-6 bg-gradient-to-br from-blue-50/50 to-purple-50/50 dark:from-gray-800 dark:to-gray-900 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10 dark:opacity-5">
        <div className="absolute top-20 left-20 w-64 h-64 bg-blue-400 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-64 h-64 bg-purple-400 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-3 mb-4">
            <Users className="w-12 h-12 text-blue-600 dark:text-blue-400" />
            <h2 className="text-5xl text-gray-800 dark:text-white">أهل القرية ومهنهم</h2>
            <Users className="w-12 h-12 text-blue-600 dark:text-blue-400" />
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 mt-4 max-w-2xl mx-auto">
            تعرف على بعض من أبناء القرية وتخصصاتهم المتنوعة
          </p>
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: 100 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto rounded-full mt-4"
          />
        </motion.div>

        {/* People Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {professions.map((person, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              whileHover={{ y: -10, scale: 1.05 }}
              className="group relative"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${person.color} rounded-3xl blur-xl opacity-0 group-hover:opacity-40 transition-opacity`}></div>
              <div className="relative bg-white dark:bg-gray-800 rounded-3xl shadow-xl overflow-hidden border border-gray-100 dark:border-gray-700">
                <div className={`h-2 bg-gradient-to-r ${person.color}`}></div>
                <div className="p-6 text-center">
                  {/* Avatar */}
                  <div className="relative inline-block mb-4">
                    <motion.div
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                      className="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-600 rounded-full flex items-center justify-center text-5xl shadow-lg"
                    >
                      {person.icon}
                    </motion.div>
                    <div className={`absolute -bottom-2 -right-2 p-2 bg-gradient-to-br ${person.color} rounded-full shadow-xl group-hover:scale-125 transition-transform`}>
                      <Briefcase className="w-4 h-4 text-white" />
                    </div>
                  </div>
                  <h3 className="text-xl text-gray-800 dark:text-white mb-2">{person.name}</h3>
                  <p className="text-gray-600 dark:text-gray-300">{person.profession}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Community Message */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-amber-500 to-orange-600 rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity"></div>
          <div className="relative bg-gradient-to-br from-amber-100 to-orange-100 dark:from-amber-900/40 dark:to-orange-900/40 rounded-3xl shadow-2xl p-12 border border-amber-200 dark:border-amber-800 text-center">
            <div className="max-w-3xl mx-auto">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="inline-flex items-center justify-center gap-3 mb-6"
              >
                <Users className="w-16 h-16 text-amber-600 dark:text-amber-400" />
              </motion.div>
              <h3 className="text-4xl text-gray-800 dark:text-white mb-6">
                مجتمع متنوع ومتكامل
              </h3>
              <p className="text-xl text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
                كل فرد في قريتنا له دوره المهم. من المزارع الذي يزرع الأرض، إلى المعلم الذي يعلم الأجيال،
                إلى الطبيب الذي يرعى الصحة، إلى الحرفي الذي يبني ويصلح.
                معاً نصنع مجتمعاً قوياً ومزدهراً.
              </p>
              <div className="flex items-center justify-center gap-4">
                <motion.div
                  animate={{ width: [0, 64, 0] }}
                  transition={{ duration: 3, repeat: Infinity }}
                  className="h-1 bg-gradient-to-r from-transparent via-amber-500 to-transparent rounded-full"
                />
                <span className="text-3xl">❤️</span>
                <motion.div
                  animate={{ width: [0, 64, 0] }}
                  transition={{ duration: 3, repeat: Infinity, delay: 1.5 }}
                  className="h-1 bg-gradient-to-l from-transparent via-amber-500 to-transparent rounded-full"
                />
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
