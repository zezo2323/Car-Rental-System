import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import About from '../components/About';
import Places from '../components/Places';
import PlacesGallery from '../components/PlacesGallery';
import Specialty from '../components/Specialty';
import Community from '../components/Community';
import Gallery from '../components/Gallery';
import Testimonials from '../components/Testimonials';
import Contact from '../components/Contact';
import Footer from '../components/Footer';

interface MainSiteProps {
  onNavigateToAdmin?: () => void;
}

export default function MainSite({ onNavigateToAdmin }: MainSiteProps) {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    if (!darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-green-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-500">
      <Navbar darkMode={darkMode} toggleDarkMode={toggleDarkMode} onNavigateToAdmin={onNavigateToAdmin} />
      <Hero />
      <About />
      <Places />
      <PlacesGallery />
      <Specialty />
      <Community />
      <Gallery />
      <Testimonials />
      <Contact />
      <Footer />
    </div>
  );
}
