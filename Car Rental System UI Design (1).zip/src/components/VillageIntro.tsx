import React from 'react';
import { Home, HandHeart, TreePine, Sparkles } from 'lucide-react';

export default function VillageIntro() {
  return (
    <section className="py-24 px-8 relative">
      <div className="max-w-6xl mx-auto">
        {/* Section title */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-4">
            <Sparkles className="w-8 h-8 text-amber-500" />
            <h2 className="text-4xl text-gray-800">عن قريتنا</h2>
            <Sparkles className="w-8 h-8 text-amber-500" />
          </div>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-amber-500 to-transparent mx-auto"></div>
        </div>

        {/* Main intro card */}
        <div className="bg-gradient-to-br from-white to-amber-50 rounded-3xl shadow-2xl p-12 mb-12 border border-amber-200/50">
          <div className="flex items-start gap-6 mb-8">
            <div className="p-4 bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl shadow-lg">
              <Home className="w-12 h-12 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-3xl text-gray-800 mb-4">شنراق الخير</h3>
              <p className="text-xl text-gray-700 leading-relaxed">
                قرية عريقة تتميز بأهلها الطيبين وتقاليدها الأصيلة وروح التعاون والمحبة التي تجمع سكانها. 
                نسيج اجتماعي متين يجمع بين الماضي العريق والحاضر المشرق.
              </p>
            </div>
          </div>

          {/* Features grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div className="p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-md hover:shadow-xl transition-shadow border border-amber-100">
              <div className="flex items-center gap-3 mb-3">
                <HandHeart className="w-8 h-8 text-green-600" />
                <h4 className="text-xl text-gray-800">أهل طيبون</h4>
              </div>
              <p className="text-gray-600 leading-relaxed">
                يُعرف أهل القرية بكرمهم وحسن ضيافتهم وتعاونهم المستمر فيما بينهم
              </p>
            </div>

            <div className="p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-md hover:shadow-xl transition-shadow border border-amber-100">
              <div className="flex items-center gap-3 mb-3">
                <TreePine className="w-8 h-8 text-amber-600" />
                <h4 className="text-xl text-gray-800">تقاليد أصيلة</h4>
              </div>
              <p className="text-gray-600 leading-relaxed">
                نحافظ على عاداتنا وتقاليدنا الموروثة ونعتز بها ونورثها للأجيال القادمة
              </p>
            </div>

            <div className="p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-md hover:shadow-xl transition-shadow border border-amber-100">
              <div className="flex items-center gap-3 mb-3">
                <Sparkles className="w-8 h-8 text-purple-600" />
                <h4 className="text-xl text-gray-800">وحدة وتكاتف</h4>
              </div>
              <p className="text-gray-600 leading-relaxed">
                نجتمع في الأفراح والأحزان ونتشارك في بناء مستقبل أفضل لقريتنا
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
