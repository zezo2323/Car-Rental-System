import { useState } from 'react';
import { motion } from 'motion/react';
import { Car, Users, Zap, Fuel, Search, Filter } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { mockCars } from '../lib/mock-data';

interface CarsListPageProps {
  onNavigate: (page: string, data?: any) => void;
}

export function CarsListPage({ onNavigate }: CarsListPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = ['all', 'sedan', 'suv', 'sports', 'luxury', 'electric'];

  const filteredCars = mockCars.filter(car => {
    const matchesSearch = car.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         car.brand.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || car.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-primary mb-2">Available Cars</h1>
        <p className="text-muted-foreground">Choose from our premium collection of vehicles</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search cars..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              onClick={() => setSelectedCategory(category)}
              className="capitalize whitespace-nowrap"
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Cars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCars.map((car, index) => (
          <motion.div
            key={car.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="group rounded-2xl bg-card border border-border overflow-hidden hover:shadow-xl transition-all duration-300"
          >
            {/* Image */}
            <div className="relative h-48 overflow-hidden bg-muted">
              <img
                src={car.image}
                alt={car.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs ${
                car.available
                  ? 'bg-green-500/90 text-white'
                  : 'bg-red-500/90 text-white'
              }`}>
                {car.available ? 'Available' : 'Rented'}
              </div>
              <div className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs bg-primary/90 text-primary-foreground capitalize">
                {car.category}
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              <div>
                <h3 className="mb-1">{car.name}</h3>
                <p className="text-sm text-muted-foreground">{car.brand} {car.model}</p>
              </div>

              {/* Features */}
              <div className="grid grid-cols-3 gap-2">
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Users className="w-4 h-4" />
                  {car.seats} seats
                </div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Zap className="w-4 h-4" />
                  {car.transmission}
                </div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Fuel className="w-4 h-4" />
                  {car.fuelType}
                </div>
              </div>

              {/* Features List */}
              <div className="flex flex-wrap gap-2">
                {car.features.slice(0, 3).map((feature) => (
                  <span
                    key={feature}
                    className="px-2 py-1 rounded-lg bg-muted text-xs"
                  >
                    {feature}
                  </span>
                ))}
              </div>

              {/* Price & Action */}
              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div>
                  <p className="text-2xl text-primary">${car.pricePerDay}</p>
                  <p className="text-xs text-muted-foreground">per day</p>
                </div>
                <Button
                  onClick={() => onNavigate('rental', { car })}
                  disabled={!car.available}
                  className="rounded-xl"
                >
                  {car.available ? 'Rent Now' : 'Not Available'}
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredCars.length === 0 && (
        <div className="text-center py-12">
          <Car className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="mb-2">No cars found</h3>
          <p className="text-muted-foreground">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}
