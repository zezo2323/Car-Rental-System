import { motion } from 'motion/react';
import { Search, Calendar, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HeroProps {
  onNavigate: (section: string) => void;
}

export function Hero({ onNavigate }: HeroProps) {
  return (
    <section className="relative min-h-screen flex items-center pt-20">
      {/* Background Image */}
      <div className="absolute inset-0 -z-10">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1687993320698-456243eb9a3d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBjYXIlMjByZW50YWx8ZW58MXx8fHwxNzY0ODQ4MzIyfDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="سيارات فاخرة"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
      </div>

      <div className="container mx-auto px-4">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.h1
              className="text-foreground mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              استأجر سيارتك المثالية
              <br />
              <span className="text-primary">بكل سهولة وأمان</span>
            </motion.h1>

            <motion.p
              className="text-muted-foreground mb-8 text-xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              اختر من بين مجموعة واسعة من السيارات الفاخرة والعملية لتناسب جميع
              احتياجاتك. خدمة متميزة وأسعار تنافسية في انتظارك.
            </motion.p>

            <motion.div
              className="flex flex-col sm:flex-row gap-4 mb-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <Button
                size="lg"
                className="text-lg px-8"
                onClick={() => onNavigate('cars')}
              >
                استعرض السيارات
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8"
                onClick={() => onNavigate('how-it-works')}
              >
                كيف يعمل
              </Button>
            </motion.div>

            {/* Search Card */}
            <motion.div
              className="bg-card/90 backdrop-blur-sm border border-border rounded-2xl p-6 shadow-xl"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    placeholder="موقع الاستلام"
                    className="pr-10"
                  />
                </div>
                <div className="relative">
                  <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="date"
                    placeholder="تاريخ البداية"
                    className="pr-10"
                  />
                </div>
                <div className="relative">
                  <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="date"
                    placeholder="تاريخ النهاية"
                    className="pr-10"
                  />
                </div>
              </div>
              <Button className="w-full mt-4" size="lg">
                <Search className="ml-2 w-5 h-5" />
                ابحث عن سيارة
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
