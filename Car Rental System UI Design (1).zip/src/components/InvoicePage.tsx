import { motion } from 'motion/react';
import { Car as CarIcon, Printer, Download, CheckCircle, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { useAuth } from '../lib/auth-context';
import { Car } from '../lib/mock-data';

interface InvoicePageProps {
  rental: any;
  car: Car;
  onNavigate: (page: string) => void;
}

export function InvoicePage({ rental, car, onNavigate }: InvoicePageProps) {
  const { user } = useAuth();

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    window.print(); // In a real app, you'd generate a PDF
  };

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8">
      {/* Actions Bar */}
      <div className="no-print flex items-center justify-between">
        <Button
          variant="ghost"
          onClick={() => onNavigate('cars-list')}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Cars
        </Button>

        <div className="flex gap-2">
          <Button variant="outline" onClick={handleDownload}>
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
          <Button onClick={handlePrint}>
            <Printer className="w-4 h-4 mr-2" />
            Print Invoice
          </Button>
        </div>
      </div>

      {/* Success Message */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="no-print text-center p-8 rounded-2xl bg-green-500/10 border border-green-500/20"
      >
        <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
        <h2 className="text-green-500 mb-2">Booking Confirmed!</h2>
        <p className="text-muted-foreground">Your rental has been successfully confirmed. Invoice details below.</p>
      </motion.div>

      {/* Invoice */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl bg-card border border-border overflow-hidden"
      >
        {/* Invoice Header */}
        <div className="p-8 bg-primary/5 border-b border-border">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
                  <CarIcon className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h2 className="text-primary">Car Rental System</h2>
                  <p className="text-sm text-muted-foreground">Premium Car Rentals</p>
                </div>
              </div>
              <div className="text-sm text-muted-foreground space-y-1">
                <p>123 Business Street</p>
                <p>New York, NY 10001</p>
                <p>contact@carrental.com</p>
                <p>+1 (555) 123-4567</p>
              </div>
            </div>
            <div className="text-right">
              <h1 className="mb-2">INVOICE</h1>
              <div className="text-sm space-y-1">
                <p className="text-muted-foreground">Invoice #: <span className="text-foreground">{rental.id}</span></p>
                <p className="text-muted-foreground">Date: <span className="text-foreground">{new Date().toLocaleDateString()}</span></p>
                <p className="text-muted-foreground">Status: <span className="text-green-500">Confirmed</span></p>
              </div>
            </div>
          </div>
        </div>

        {/* Customer & Rental Info */}
        <div className="p-8 grid grid-cols-2 gap-8 border-b border-border">
          <div>
            <h4 className="mb-3">Bill To:</h4>
            <div className="text-sm space-y-1">
              <p>{user?.name}</p>
              <p className="text-muted-foreground">{user?.email}</p>
              {user?.phone && <p className="text-muted-foreground">{user.phone}</p>}
            </div>
          </div>
          <div>
            <h4 className="mb-3">Rental Period:</h4>
            <div className="text-sm space-y-1">
              <p className="text-muted-foreground">Pickup: <span className="text-foreground">{rental.startDate}</span></p>
              <p className="text-muted-foreground">Return: <span className="text-foreground">{rental.endDate}</span></p>
              <p className="text-muted-foreground">Duration: <span className="text-foreground">{rental.totalDays} days</span></p>
            </div>
          </div>
        </div>

        {/* Car Details */}
        <div className="p-8 border-b border-border">
          <h4 className="mb-4">Vehicle Information:</h4>
          <div className="flex gap-6">
            <div className="w-32 h-24 rounded-xl overflow-hidden bg-muted">
              <img src={car.image} alt={car.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 space-y-2">
              <h3>{car.name}</h3>
              <p className="text-sm text-muted-foreground">{car.brand} {car.model} • {car.year}</p>
              <div className="flex gap-4 text-xs text-muted-foreground">
                <span>{car.seats} Seats</span>
                <span>•</span>
                <span className="capitalize">{car.transmission}</span>
                <span>•</span>
                <span>{car.fuelType}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Price Breakdown */}
        <div className="p-8">
          <h4 className="mb-4">Payment Details:</h4>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Daily Rate</span>
              <span>${car.pricePerDay.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Number of Days</span>
              <span>{rental.totalDays}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span>${rental.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Tax (15%)</span>
              <span>${rental.tax.toFixed(2)}</span>
            </div>
            <div className="pt-3 border-t border-border flex justify-between">
              <span className="text-lg">Total Amount</span>
              <span className="text-2xl text-primary">${rental.totalAmount.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-8 bg-muted/50 border-t border-border">
          <div className="text-sm text-center text-muted-foreground space-y-2">
            <p>Thank you for choosing our car rental service!</p>
            <p>Please keep this invoice for your records.</p>
            <p className="text-xs">Terms & Conditions apply. For support, contact us at support@carrental.com</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
