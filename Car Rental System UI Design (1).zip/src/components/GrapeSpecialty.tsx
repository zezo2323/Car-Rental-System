import React from 'react';
import { Grape, Award, Sun, Droplets, TrendingUp } from 'lucide-react';

export default function GrapeSpecialty() {
  return (
    <section className="py-24 px-8 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-white to-green-50 -z-10"></div>
      <div className="absolute top-10 right-10 w-64 h-64 bg-purple-200 rounded-full blur-3xl opacity-20"></div>
      <div className="absolute bottom-10 left-10 w-64 h-64 bg-green-200 rounded-full blur-3xl opacity-20"></div>

      <div className="max-w-6xl mx-auto">
        {/* Section title */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-4">
            <Grape className="w-10 h-10 text-purple-600" />
            <h2 className="text-4xl text-gray-800">تخصصنا الرئيسي</h2>
            <Grape className="w-10 h-10 text-purple-600" />
          </div>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-purple-500 to-transparent mx-auto"></div>
        </div>

        {/* Main specialty card */}
        <div className="bg-gradient-to-br from-white to-purple-50 rounded-3xl shadow-2xl overflow-hidden border border-purple-200/50">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-12">
            {/* Left side - Image/Illustration */}
            <div className="flex items-center justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-400 to-green-400 rounded-3xl blur-xl opacity-30 animate-pulse"></div>
                <div className="relative bg-gradient-to-br from-purple-100 to-green-100 rounded-3xl p-12 shadow-xl">
                  <Grape className="w-48 h-48 text-purple-600" strokeWidth={1} />
                  <div className="absolute top-4 right-4 p-3 bg-yellow-400 rounded-full shadow-lg animate-bounce">
                    <Award className="w-8 h-8 text-white" />
                  </div>
                </div>
              </div>
            </div>

            {/* Right side - Content */}
            <div className="flex flex-col justify-center">
              <h3 className="text-3xl text-gray-800 mb-4">زراعة العنب وإنتاج الزبيب</h3>
              <p className="text-xl text-gray-700 leading-relaxed mb-6">
                تشتهر قرية شنراق الخير بزراعة العنب عالي الجودة وإنتاج الزبيب الفاخر. 
                تمتد مزارع العنب على مساحات واسعة وتستفيد من المناخ المثالي والتربة الخصبة.
              </p>

              {/* Quality points */}
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-4 bg-white/80 backdrop-blur-sm rounded-xl shadow-md">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <Sun className="w-6 h-6 text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="text-lg text-gray-800 mb-1">مناخ مثالي</h4>
                    <p className="text-gray-600">أشعة الشمس الوفيرة والطقس المناسب لزراعة أجود أنواع العنب</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-white/80 backdrop-blur-sm rounded-xl shadow-md">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Droplets className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-lg text-gray-800 mb-1">تربة خصبة</h4>
                    <p className="text-gray-600">أرض غنية بالمعادن تمنح العنب مذاقاً فريداً ونوعية ممتازة</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-white/80 backdrop-blur-sm rounded-xl shadow-md">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h4 className="text-lg text-gray-800 mb-1">جودة عالية</h4>
                    <p className="text-gray-600">منتجات طبيعية 100% يتم تجفيفها وتعبئتها وفق أعلى المعايير</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom stats bar */}
          <div className="bg-gradient-to-r from-purple-600 to-green-600 p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center text-white">
              <div>
                <div className="text-4xl mb-2">🍇</div>
                <p className="text-2xl mb-1">أجود الأنواع</p>
                <p className="text-purple-100">عنب ممتاز</p>
              </div>
              <div>
                <div className="text-4xl mb-2">🌿</div>
                <p className="text-2xl mb-1">طبيعي 100%</p>
                <p className="text-purple-100">بدون إضافات</p>
              </div>
              <div>
                <div className="text-4xl mb-2">⭐</div>
                <p className="text-2xl mb-1">تراث عريق</p>
                <p className="text-purple-100">خبرة أجيال</p>
              </div>
            </div>
          </div>
        </div>

        {/* Additional info cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-purple-100 hover:shadow-xl transition-shadow">
            <h4 className="text-xl text-gray-800 mb-3 flex items-center gap-2">
              <span className="text-2xl">🌾</span>
              موسم الحصاد
            </h4>
            <p className="text-gray-600 leading-relaxed">
              يبدأ موسم قطف العنب في أواخر الصيف، حيث يجتمع أهل القرية في جو من الفرح والتعاون لجني المحصول
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-6 border border-green-100 hover:shadow-xl transition-shadow">
            <h4 className="text-xl text-gray-800 mb-3 flex items-center gap-2">
              <span className="text-2xl">📦</span>
              التسويق والبيع
            </h4>
            <p className="text-gray-600 leading-relaxed">
              يتم تسويق الزبيب في الأسواق المحلية والإقليمية، ونفخر بسمعتنا الطيبة في جودة منتجاتنا
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
