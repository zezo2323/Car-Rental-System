import { useState, useEffect } from 'react';
import { Toaster } from 'sonner@2.0.3';
import { AuthProvider, useAuth } from './lib/auth-context';
import { ThemeProvider, useTheme } from './lib/theme-provider';
import { Sun, Moon, LogOut } from 'lucide-react';
import { Button } from './components/ui/button';
import { LoginPage } from './components/LoginPage';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { CarsListPage } from './components/CarsListPage';
import { RentalPage } from './components/RentalPage';
import { InvoicePage } from './components/InvoicePage';
import { CommentsPage } from './components/CommentsPage';
import { RentalsPage } from './components/RentalsPage';
import { CarsManagement } from './components/CarsManagement';
import { UsersPage } from './components/UsersPage';

function AppContent() {
  const { user, logout, isAdmin } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [currentPage, setCurrentPage] = useState('login');
  const [pageData, setPageData] = useState<any>(null);

  useEffect(() => {
    if (user) {
      if (isAdmin) {
        setCurrentPage('dashboard');
      } else {
        setCurrentPage('cars-list');
      }
    } else {
      setCurrentPage('login');
    }
  }, [user, isAdmin]);

  const handleNavigate = (page: string, data?: any) => {
    setCurrentPage(page);
    setPageData(data || null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogout = () => {
    logout();
    handleNavigate('login');
  };

  if (!user) {
    return <LoginPage onNavigate={handleNavigate} />;
  }

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar currentPage={currentPage} onNavigate={handleNavigate} />

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* Top Bar */}
        <div className="fixed top-0 left-0 right-0 h-16 bg-card/80 backdrop-blur-lg border-b border-border z-30 no-print">
          <div className="h-full px-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="icon"
                onClick={toggleTheme}
                className="rounded-full"
              >
                {theme === 'dark' ? (
                  <Sun className="w-5 h-5" />
                ) : (
                  <Moon className="w-5 h-5" />
                )}
              </Button>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-left">
                <p className="text-sm">{user.name}</p>
                <p className="text-xs text-muted-foreground">{user.email}</p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                className="rounded-full hover:bg-destructive/10 hover:text-destructive"
              >
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Pages */}
        <div className="pt-16">
          {currentPage === 'dashboard' && <Dashboard onNavigate={handleNavigate} />}
          {currentPage === 'cars' && <CarsManagement />}
          {currentPage === 'cars-list' && <CarsListPage onNavigate={handleNavigate} />}
          {currentPage === 'rental' && pageData?.car && (
            <RentalPage car={pageData.car} onNavigate={handleNavigate} />
          )}
          {currentPage === 'invoice' && pageData?.rental && pageData?.car && (
            <InvoicePage
              rental={pageData.rental}
              car={pageData.car}
              onNavigate={handleNavigate}
            />
          )}
          {currentPage === 'comments' && <CommentsPage />}
          {currentPage === 'rentals' && <RentalsPage onNavigate={handleNavigate} />}
          {currentPage === 'my-rentals' && <RentalsPage onNavigate={handleNavigate} />}
          {currentPage === 'users' && <UsersPage />}
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="dark">
      <AuthProvider>
        <AppContent />
        <Toaster position="top-center" richColors />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
