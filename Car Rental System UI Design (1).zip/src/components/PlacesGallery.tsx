import React from 'react';
import { motion } from 'motion/react';
import { Building2, School, Store, Hospital, MapPin } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export default function PlacesGallery() {
  const places = [
    {
      title: 'المساجد',
      description: 'مساجد القرية العريقة التي تجمع أهل القرية للصلاة والعبادة',
      image: 'https://images.unsplash.com/photo-1624140932334-6bbc79e68397?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3NxdWUlMjBhcmNoaXRlY3R1cmUlMjBpc2xhbWljfGVufDF8fHx8MTc2NDAyNzcxNnww&ixlib=rb-4.1.0&q=80&w=1080',
      icon: Building2,
      color: 'from-green-500 to-emerald-600',
      stats: ['3 مساجد', '500+ مصلي', 'دروس يومية'],
    },
    {
      title: 'المدارس',
      description: 'مدارس حديثة تقدم تعليماً متميزاً لأبناء القرية',
      image: 'https://images.unsplash.com/photo-1699347914988-c61ec13c99c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2hvb2wlMjBidWlsZGluZyUyMGVkdWNhdGlvbnxlbnwxfHx8fDE3NjM5NDkzMDF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      icon: School,
      color: 'from-blue-500 to-cyan-600',
      stats: ['مدرستان', '300+ طالب', 'معلمون أكفاء'],
    },
    {
      title: 'المحلات التجارية',
      description: 'محلات تجارية متنوعة تلبي احتياجات السكان اليومية',
      image: 'https://images.unsplash.com/photo-1667557055212-ec7ec6822661?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsb2NhbCUyMHNob3AlMjBtYXJrZXQlMjBzdG9yZXxlbnwxfHx8fDE3NjQwMjc3MTd8MA&ixlib=rb-4.1.0&q=80&w=1080',
      icon: Store,
      color: 'from-orange-500 to-amber-600',
      stats: ['15+ محل', 'سوق يومي', 'منتجات محلية'],
    },
    {
      title: 'الصيدليات والمراكز الصحية',
      description: 'خدمات صحية متكاملة ورعاية طبية لجميع السكان',
      image: 'https://images.unsplash.com/photo-1739289696449-cba3a5ef085d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaGFybWFjeSUyMG1lZGljYWwlMjBkcnVnc3RvcmV8ZW58MXx8fHwxNzY0MDI3NzE3fDA&ixlib=rb-4.1.0&q=80&w=1080',
      icon: Hospital,
      color: 'from-red-500 to-rose-600',
      stats: ['صيدليتان', 'عيادة طبية', 'خدمة 24/7'],
    },
  ];

  return (
    <section className="py-32 px-6 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10 dark:opacity-5">
        <div className="absolute top-20 left-20 w-96 h-96 bg-purple-400 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-400 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-3 mb-4">
            <MapPin className="w-10 h-10 text-purple-600 dark:text-purple-400" />
            <h2 className="text-5xl text-gray-800 dark:text-white">استكشف أماكن القرية</h2>
            <MapPin className="w-10 h-10 text-purple-600 dark:text-purple-400" />
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 mt-4 max-w-2xl mx-auto">
            جولة مصورة في أهم معالم وأماكن قريتنا الجميلة
          </p>
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: 100 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="h-1 bg-gradient-to-r from-purple-500 to-blue-500 mx-auto rounded-full mt-4"
          />
        </motion.div>

        {/* Places Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {places.map((place, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.8 }}
              whileHover={{ y: -10, scale: 1.02 }}
              className="group relative"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${place.color} rounded-3xl blur-xl opacity-0 group-hover:opacity-40 transition-opacity`}></div>
              <div className="relative bg-white dark:bg-gray-800 rounded-3xl shadow-2xl overflow-hidden border border-gray-100 dark:border-gray-700">
                {/* Image */}
                <div className="relative h-64 overflow-hidden">
                  <ImageWithFallback
                    src={place.image}
                    alt={place.title}
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
                  
                  {/* Icon Badge */}
                  <div className={`absolute top-4 right-4 p-3 bg-gradient-to-br ${place.color} rounded-xl shadow-xl`}>
                    <place.icon className="w-8 h-8 text-white" />
                  </div>

                  {/* Title Overlay */}
                  <div className="absolute bottom-4 right-4 left-4">
                    <h3 className="text-3xl text-white mb-1">{place.title}</h3>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
                    {place.description}
                  </p>

                  {/* Stats */}
                  <div className="flex flex-wrap gap-3">
                    {place.stats.map((stat, idx) => (
                      <div
                        key={idx}
                        className={`px-4 py-2 bg-gradient-to-br ${place.color} bg-opacity-10 rounded-xl text-sm`}
                      >
                        <span className="bg-gradient-to-r bg-clip-text text-transparent font-medium" style={{
                          backgroundImage: `linear-gradient(to right, var(--tw-gradient-stops))`,
                          WebkitBackgroundClip: 'text',
                          WebkitTextFillColor: 'transparent',
                        }}>
                          {stat}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="mt-12 relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-blue-500 rounded-3xl blur-xl opacity-20 group-hover:opacity-30 transition-opacity"></div>
          <div className="relative bg-gradient-to-br from-purple-100 to-blue-100 dark:from-purple-900/40 dark:to-blue-900/40 rounded-3xl shadow-xl p-10 border border-purple-200 dark:border-purple-800 text-center">
            <h3 className="text-3xl text-gray-800 dark:text-white mb-4">خدمات شاملة للمجتمع</h3>
            <p className="text-xl text-gray-700 dark:text-gray-300 leading-relaxed max-w-3xl mx-auto">
              توفر قريتنا جميع الخدمات الأساسية التي يحتاجها السكان من مرافق دينية وتعليمية وصحية وتجارية،
              مما يجعلها بيئة متكاملة للعيش الكريم والحياة الطيبة.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
