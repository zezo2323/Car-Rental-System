import { useState } from 'react';
import { motion } from 'motion/react';
import {
  Car,
  Users,
  MessageSquare,
  Calendar,
  Plus,
  Edit,
  Trash2,
  BarChart3,
  TrendingUp,
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { Badge } from './ui/badge';
import { cars, bookings, contactMessages } from '../lib/data';
import { useAuth } from '../lib/auth-context';

interface AdminDashboardProps {
  onNavigate: (section: string) => void;
}

const stats = [
  {
    title: 'إجمالي السيارات',
    value: cars.length.toString(),
    icon: Car,
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
  {
    title: 'السيارات المتاحة',
    value: cars.filter((c) => c.available).length.toString(),
    icon: Car,
    color: 'text-secondary',
    bgColor: 'bg-secondary/10',
  },
  {
    title: 'الحجوزات النشطة',
    value: bookings.filter((b) => b.status === 'confirmed').length.toString(),
    icon: Calendar,
    color: 'text-accent',
    bgColor: 'bg-accent/10',
  },
  {
    title: 'الرسائل الجديدة',
    value: contactMessages.filter((m) => m.status === 'new').length.toString(),
    icon: MessageSquare,
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
];

export function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const { isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <h3 className="mb-2">غير مصرح</h3>
            <p className="text-muted-foreground mb-4">
              هذه الصفحة متاحة للمديرين فقط
            </p>
            <Button onClick={() => onNavigate('home')}>العودة للرئيسية</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <section className="min-h-screen pt-28 pb-12 px-4">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h2 className="mb-2">لوحة التحكم</h2>
          <p className="text-muted-foreground">
            إدارة السيارات والحجوزات والمحتوى
          </p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">
                        {stat.title}
                      </p>
                      <h3>{stat.value}</h3>
                    </div>
                    <div className={`${stat.bgColor} ${stat.color} p-3 rounded-lg`}>
                      <stat.icon className="w-6 h-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="cars">السيارات</TabsTrigger>
            <TabsTrigger value="bookings">الحجوزات</TabsTrigger>
            <TabsTrigger value="messages">الرسائل</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    إحصائيات الأداء
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">معدل الحجز</span>
                        <span className="text-sm">85%</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[85%]" />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">رضا العملاء</span>
                        <span className="text-sm">92%</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-secondary w-[92%]" />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">السيارات المتاحة</span>
                        <span className="text-sm">67%</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-accent w-[67%]" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-primary" />
                    الحجوزات الأخيرة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {bookings.slice(0, 3).map((booking) => {
                      const car = cars.find((c) => c.id === booking.carId);
                      return (
                        <div
                          key={booking.id}
                          className="flex items-center justify-between p-3 bg-muted rounded-lg"
                        >
                          <div>
                            <p className="text-sm">{car?.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {booking.userName}
                            </p>
                          </div>
                          <Badge>{booking.status}</Badge>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Cars Tab */}
          <TabsContent value="cars">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>إدارة السيارات</CardTitle>
                    <CardDescription>عرض وتعديل السيارات المتاحة</CardDescription>
                  </div>
                  <Button>
                    <Plus className="ml-2 w-4 h-4" />
                    إضافة سيارة
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>السيارة</TableHead>
                      <TableHead>الفئة</TableHead>
                      <TableHead>السعر</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead>الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cars.map((car) => (
                      <TableRow key={car.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <img
                              src={car.image}
                              alt={car.name}
                              className="w-12 h-12 rounded-lg object-cover"
                            />
                            <div>
                              <p>{car.name}</p>
                              <p className="text-xs text-muted-foreground">
                                {car.brand}
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{car.category}</TableCell>
                        <TableCell>{car.pricePerDay} ر.س</TableCell>
                        <TableCell>
                          <Badge variant={car.available ? 'default' : 'destructive'}>
                            {car.available ? 'متاحة' : 'محجوزة'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button size="icon" variant="ghost">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button size="icon" variant="ghost">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bookings Tab */}
          <TabsContent value="bookings">
            <Card>
              <CardHeader>
                <CardTitle>إدارة الحجوزات</CardTitle>
                <CardDescription>عرض وإدارة جميع الحجوزات</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>العميل</TableHead>
                      <TableHead>السيارة</TableHead>
                      <TableHead>التاريخ</TableHead>
                      <TableHead>المبلغ</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead>الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bookings.map((booking) => {
                      const car = cars.find((c) => c.id === booking.carId);
                      return (
                        <TableRow key={booking.id}>
                          <TableCell>
                            <div>
                              <p>{booking.userName}</p>
                              <p className="text-xs text-muted-foreground">
                                {booking.userEmail}
                              </p>
                            </div>
                          </TableCell>
                          <TableCell>{car?.name}</TableCell>
                          <TableCell>
                            <div>
                              <p className="text-sm">{booking.startDate}</p>
                              <p className="text-xs text-muted-foreground">
                                إلى {booking.endDate}
                              </p>
                            </div>
                          </TableCell>
                          <TableCell>{booking.totalPrice} ر.س</TableCell>
                          <TableCell>
                            <Badge>{booking.status}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button size="icon" variant="ghost">
                                <Edit className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages">
            <Card>
              <CardHeader>
                <CardTitle>الرسائل</CardTitle>
                <CardDescription>رسائل التواصل من العملاء</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>الاسم</TableHead>
                      <TableHead>البريد الإلكتروني</TableHead>
                      <TableHead>الرسالة</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead>التاريخ</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contactMessages.map((message) => (
                      <TableRow key={message.id}>
                        <TableCell>{message.name}</TableCell>
                        <TableCell>{message.email}</TableCell>
                        <TableCell className="max-w-xs truncate">
                          {message.message}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={message.status === 'new' ? 'default' : 'secondary'}
                          >
                            {message.status === 'new' ? 'جديدة' : 'مقروءة'}
                          </Badge>
                        </TableCell>
                        <TableCell>{message.createdAt}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}
