import { useState } from 'react';
import { motion } from 'motion/react';
import { Calendar, User, DollarSign, Clock, Eye, XCircle } from 'lucide-react';
import { Button } from './ui/button';
import { useAuth } from '../lib/auth-context';
import { mockRentals, mockCars, mockUsers } from '../lib/mock-data';
import { toast } from 'sonner@2.0.3';

interface RentalsPageProps {
  onNavigate: (page: string, data?: any) => void;
}

export function RentalsPage({ onNavigate }: RentalsPageProps) {
  const { user, isAdmin } = useAuth();
  const [rentals, setRentals] = useState(mockRentals);

  const filteredRentals = isAdmin
    ? rentals
    : rentals.filter(r => r.userId === user?.id);

  const handleCancelRental = (rentalId: string) => {
    setRentals(rentals.map(r =>
      r.id === rentalId ? { ...r, status: 'cancelled' as const } : r
    ));
    toast.success('Rental cancelled successfully');
  };

  const calculateRemainingDays = (endDate: string) => {
    const end = new Date(endDate);
    const now = new Date();
    const diffTime = end.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(0, diffDays);
  };

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-primary mb-2">
          {isAdmin ? 'Active Rentals' : 'My Rentals'}
        </h1>
        <p className="text-muted-foreground">
          {isAdmin ? 'Manage all ongoing car rentals' : 'View and manage your rental bookings'}
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl">{filteredRentals.filter(r => r.status === 'active').length}</p>
              <p className="text-xs text-muted-foreground">Active</p>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <Clock className="w-5 h-5 text-green-500" />
            </div>
            <div>
              <p className="text-2xl">{filteredRentals.filter(r => r.status === 'completed').length}</p>
              <p className="text-xs text-muted-foreground">Completed</p>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
              <XCircle className="w-5 h-5 text-red-500" />
            </div>
            <div>
              <p className="text-2xl">{filteredRentals.filter(r => r.status === 'cancelled').length}</p>
              <p className="text-xs text-muted-foreground">Cancelled</p>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-2xl">${filteredRentals.reduce((sum, r) => sum + r.totalAmount, 0)}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </div>
          </div>
        </div>
      </div>

      {/* Rentals Table */}
      <div className="rounded-2xl bg-card border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                <th className="px-6 py-4 text-left text-sm">Rental ID</th>
                <th className="px-6 py-4 text-left text-sm">Car</th>
                {isAdmin && <th className="px-6 py-4 text-left text-sm">Customer</th>}
                <th className="px-6 py-4 text-left text-sm">Period</th>
                <th className="px-6 py-4 text-left text-sm">Duration</th>
                <th className="px-6 py-4 text-left text-sm">Amount</th>
                <th className="px-6 py-4 text-left text-sm">Status</th>
                <th className="px-6 py-4 text-left text-sm">Days Left</th>
                <th className="px-6 py-4 text-left text-sm">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredRentals.map((rental, index) => {
                const car = mockCars.find(c => c.id === rental.carId);
                const customer = mockUsers.find(u => u.id === rental.userId);
                const remainingDays = calculateRemainingDays(rental.endDate);

                return (
                  <motion.tr
                    key={rental.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-border hover:bg-muted/50 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <span className="text-sm text-primary">{rental.id}</span>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-10 rounded-lg overflow-hidden bg-muted">
                          {car && (
                            <img
                              src={car.image}
                              alt={car.name}
                              className="w-full h-full object-cover"
                            />
                          )}
                        </div>
                        <div>
                          <p className="text-sm">{car?.name}</p>
                          <p className="text-xs text-muted-foreground">{car?.brand}</p>
                        </div>
                      </div>
                    </td>

                    {isAdmin && (
                      <td className="px-6 py-4">
                        <div>
                          <p className="text-sm">{customer?.name}</p>
                          <p className="text-xs text-muted-foreground">{customer?.email}</p>
                        </div>
                      </td>
                    )}

                    <td className="px-6 py-4">
                      <div className="text-sm space-y-1">
                        <p className="text-muted-foreground">From: {rental.startDate}</p>
                        <p className="text-muted-foreground">To: {rental.endDate}</p>
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <span className="text-sm">{rental.totalDays} days</span>
                    </td>

                    <td className="px-6 py-4">
                      <span className="text-sm text-primary">${rental.totalAmount}</span>
                    </td>

                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex px-3 py-1 rounded-full text-xs ${
                          rental.status === 'active'
                            ? 'bg-green-500/10 text-green-500'
                            : rental.status === 'completed'
                            ? 'bg-blue-500/10 text-blue-500'
                            : 'bg-red-500/10 text-red-500'
                        }`}
                      >
                        {rental.status}
                      </span>
                    </td>

                    <td className="px-6 py-4">
                      {rental.status === 'active' && (
                        <span className={`text-sm ${remainingDays <= 2 ? 'text-red-500' : 'text-muted-foreground'}`}>
                          {remainingDays} days
                        </span>
                      )}
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        {rental.status === 'active' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleCancelRental(rental.id)}
                            className="hover:bg-destructive/10 hover:text-destructive"
                          >
                            Cancel
                          </Button>
                        )}
                        {car && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onNavigate('invoice', { rental, car })}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {filteredRentals.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="mb-2">No rentals found</h3>
          <p className="text-muted-foreground">
            {isAdmin ? 'No active rentals at the moment' : "You haven't made any bookings yet"}
          </p>
          {!isAdmin && (
            <Button onClick={() => onNavigate('cars-list')} className="mt-4">
              Browse Cars
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
