import { motion } from 'motion/react';
import { Award, Shield, Clock, Users, CheckCircle, TrendingUp } from 'lucide-react';
import { Card, CardContent } from './ui/card';

const features = [
  {
    icon: Shield,
    title: 'آمنة وموثوقة',
    description: 'جميع سياراتنا مؤمنة بالكامل ومفحوصة بانتظام لضمان سلامتك',
  },
  {
    icon: Award,
    title: 'جودة عالية',
    description: 'نوفر أفضل السيارات من العلامات التجارية الرائدة عالمياً',
  },
  {
    icon: Clock,
    title: 'خدمة على مدار الساعة',
    description: 'فريق الدعم متواجد 24/7 لخدمتك ومساعدتك في أي وقت',
  },
  {
    icon: Users,
    title: 'عملاء راضون',
    description: 'أكثر من 10,000 عميل سعيد استمتعوا بخدماتنا المميزة',
  },
];

const stats = [
  { value: '10,000+', label: 'عميل سعيد' },
  { value: '500+', label: 'سيارة متاحة' },
  { value: '15+', label: 'سنة خبرة' },
  { value: '98%', label: 'نسبة الرضا' },
];

export function About() {
  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="mb-4">لماذا تختارنا</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            نحن الخيار الأمثل لتأجير السيارات في المملكة، نوفر خدمة متميزة وسيارات
            بأعلى جودة
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow duration-300 group">
                <CardContent className="p-6 text-center">
                  <motion.div
                    className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4 group-hover:scale-110 transition-transform"
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <feature.icon className="w-8 h-8" />
                  </motion.div>
                  <h3 className="mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-8 md:p-12 text-white"
        >
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ scale: 0.5, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <motion.div
                  className="text-4xl md:text-5xl mb-2"
                  whileHover={{ scale: 1.1 }}
                >
                  {stat.value}
                </motion.div>
                <p className="opacity-90">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Our Values */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 grid md:grid-cols-2 gap-12 items-center"
        >
          <div>
            <h2 className="mb-6">قيمنا ورؤيتنا</h2>
            <p className="text-muted-foreground mb-6">
              نسعى لأن نكون الخيار الأول في تأجير السيارات من خلال تقديم خدمة
              استثنائية وتجربة لا تُنسى لكل عميل. نؤمن بأهمية الثقة والشفافية في
              التعامل مع عملائنا.
            </p>
            <div className="space-y-4">
              {[
                'سيارات حديثة ونظيفة',
                'أسعار شفافة بدون رسوم خفية',
                'خدمة عملاء ممتازة',
                'إجراءات حجز سريعة وسهلة',
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <div className="bg-primary/10 text-primary p-1 rounded-full">
                    <CheckCircle className="w-5 h-5" />
                  </div>
                  <span>{item}</span>
                </motion.div>
              ))}
            </div>
          </div>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-square rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1665491641262-53155eaac2b0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBpbnRlcmlvciUyMGx1eHVyeXxlbnwxfHx8fDE3NjQ4NjI0NTR8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="داخلية سيارة فاخرة"
                className="w-full h-full object-cover"
              />
            </div>
            <motion.div
              className="absolute -bottom-6 -left-6 bg-accent text-accent-foreground p-6 rounded-xl shadow-xl"
              whileHover={{ scale: 1.05 }}
            >
              <TrendingUp className="w-8 h-8 mb-2" />
              <p className="text-sm">نمو مستمر في الخدمات</p>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
