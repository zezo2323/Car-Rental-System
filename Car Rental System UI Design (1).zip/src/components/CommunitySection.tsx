import React from 'react';
import { 
  Users, 
  Briefcase, 
  Hammer, 
  Scissors, 
  Truck, 
  ChefHat,
  Paintbrush,
  Zap
} from 'lucide-react';

const professions = [
  { name: 'أحمد المزارع', profession: 'مزارع عنب', icon: '🌾', color: 'from-green-500 to-emerald-600' },
  { name: 'فاطمة المعلمة', profession: 'معلمة لغة عربية', icon: '📚', color: 'from-blue-500 to-cyan-600' },
  { name: 'خالد النجار', profession: 'نجار وحرفي', icon: '🔨', color: 'from-amber-500 to-orange-600' },
  { name: 'ليلى الطبيبة', profession: 'طبيبة عامة', icon: '⚕️', color: 'from-red-500 to-rose-600' },
  { name: 'محمود المهندس', profession: 'مهندس مدني', icon: '🏗️', color: 'from-indigo-500 to-purple-600' },
  { name: 'نورة الصيدلانية', profession: 'صيدلانية', icon: '💊', color: 'from-teal-500 to-cyan-600' },
  { name: 'سعيد الحداد', profession: 'حداد ماهر', icon: '⚒️', color: 'from-gray-600 to-slate-700' },
  { name: 'مريم الخياطة', profession: 'خياطة وتطريز', icon: '✂️', color: 'from-pink-500 to-rose-600' },
  { name: 'عبدالله السائق', profession: 'سائق نقل', icon: '🚚', color: 'from-yellow-600 to-amber-700' },
  { name: 'سارة الطباخة', profession: 'طباخة ماهرة', icon: '👩‍🍳', color: 'from-orange-500 to-red-600' },
  { name: 'عمر الكهربائي', profession: 'كهربائي', icon: '⚡', color: 'from-yellow-500 to-amber-600' },
  { name: 'هدى الرسامة', profession: 'فنانة تشكيلية', icon: '🎨', color: 'from-purple-500 to-fuchsia-600' }
];

export default function CommunitySection() {
  return (
    <section className="py-24 px-8 bg-gradient-to-br from-blue-50/50 to-purple-50/50">
      <div className="max-w-7xl mx-auto">
        {/* Section title */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-4">
            <Users className="w-10 h-10 text-blue-600" />
            <h2 className="text-4xl text-gray-800">أهل القرية ومهنهم</h2>
            <Users className="w-10 h-10 text-blue-600" />
          </div>
          <p className="text-xl text-gray-600 mt-4">
            تعرف على بعض من أبناء القرية وتخصصاتهم المتنوعة
          </p>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-blue-500 to-transparent mx-auto mt-4"></div>
        </div>

        {/* People grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {professions.map((person, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden hover:-translate-y-2 border border-gray-100"
            >
              {/* Top colored bar */}
              <div className={`h-2 bg-gradient-to-r ${person.color}`}></div>
              
              <div className="p-6 text-center">
                {/* Avatar with icon */}
                <div className="relative inline-block mb-4">
                  <div className="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center text-5xl shadow-lg group-hover:scale-110 transition-transform">
                    {person.icon}
                  </div>
                  <div className={`absolute -bottom-2 -right-2 p-2 bg-gradient-to-br ${person.color} rounded-full shadow-md`}>
                    <Briefcase className="w-4 h-4 text-white" />
                  </div>
                </div>

                {/* Info */}
                <h3 className="text-xl text-gray-800 mb-2">{person.name}</h3>
                <p className="text-gray-600">{person.profession}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Community message */}
        <div className="mt-16 bg-gradient-to-br from-amber-100 to-orange-100 rounded-3xl shadow-xl p-12 border border-amber-200 text-center">
          <div className="max-w-3xl mx-auto">
            <div className="inline-flex items-center justify-center gap-3 mb-6">
              <Users className="w-12 h-12 text-amber-600" />
            </div>
            <h3 className="text-3xl text-gray-800 mb-4">مجتمع متنوع ومتكامل</h3>
            <p className="text-xl text-gray-700 leading-relaxed">
              كل فرد في قريتنا له دوره المهم. من المزارع الذي يزرع الأرض، إلى المعلم الذي يعلم الأجيال، 
              إلى الطبيب الذي يرعى الصحة، إلى الحرفي الذي يبني ويصلح. 
              معاً نصنع مجتمعاً قوياً ومزدهراً.
            </p>
            <div className="mt-8 flex items-center justify-center gap-3">
              <div className="w-16 h-1 bg-gradient-to-r from-transparent to-amber-500 rounded-full"></div>
              <span className="text-2xl">❤️</span>
              <div className="w-16 h-1 bg-gradient-to-l from-transparent to-amber-500 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
