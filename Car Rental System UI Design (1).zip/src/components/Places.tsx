import React from 'react';
import { motion } from 'motion/react';
import {
  Building2,
  School,
  Store,
  Hospital,
  Stethoscope,
  Wrench,
  GraduationCap,
  MapPin,
  Sparkles,
  Hammer,
} from 'lucide-react';

export default function Places() {
  const places = [
    {
      icon: Building2,
      title: 'المساجد',
      description: 'بيوت الله في قريتنا، مراكز للعبادة والتواصل',
      color: 'from-green-500 to-emerald-600',
    },
    {
      icon: School,
      title: 'المدارس',
      description: 'منارات العلم والمعرفة لأبنائنا',
      color: 'from-blue-500 to-cyan-600',
    },
    {
      icon: Store,
      title: 'المحلات التجارية',
      description: 'متاجر توفر احتياجات أهل القرية اليومية',
      color: 'from-orange-500 to-amber-600',
    },
    {
      icon: Hospital,
      title: 'الصيدليات',
      description: 'رعاية صحية وأدوية لسكان القرية',
      color: 'from-red-500 to-rose-600',
    },
    {
      icon: Stethoscope,
      title: 'الأطباء',
      description: 'أطباء وممرضون يخدمون المجتمع',
      color: 'from-teal-500 to-cyan-600',
    },
    {
      icon: Wrench,
      title: 'الحرفيون',
      description: 'نجارون وحدادون وبناؤون مهرة',
      color: 'from-gray-600 to-slate-700',
    },
    {
      icon: GraduationCap,
      title: 'المعلمون',
      description: 'معلمون متفانون في تعليم الأجيال',
      color: 'from-purple-500 to-violet-600',
    },
    {
      icon: MapPin,
      title: 'الأماكن المشهورة',
      description: 'معالم وساحات يجتمع فيها الناس',
      color: 'from-pink-500 to-rose-600',
    },
  ];

  return (
    <section id="places" className="py-32 px-6 bg-gradient-to-br from-green-50/50 to-amber-50/50 dark:from-gray-800 dark:to-gray-900 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10 dark:opacity-5">
        <div className="absolute top-20 right-20 w-64 h-64 bg-green-400 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-64 h-64 bg-amber-400 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-3 mb-4">
            <MapPin className="w-10 h-10 text-green-600 dark:text-green-400" />
            <h2 className="text-5xl text-gray-800 dark:text-white">أماكن ومعالم القرية</h2>
            <MapPin className="w-10 h-10 text-green-600 dark:text-green-400" />
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 mt-4 max-w-2xl mx-auto">
            تعرف على الأماكن المهمة والخدمات المتوفرة في قريتنا
          </p>
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: 100 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="h-1 bg-gradient-to-r from-green-500 to-amber-500 mx-auto rounded-full mt-4"
          />
        </motion.div>

        {/* Places Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {places.map((place, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              whileHover={{ y: -10, scale: 1.03 }}
              className="group relative"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${place.color} rounded-3xl blur-xl opacity-0 group-hover:opacity-30 transition-opacity`}></div>
              <div className="relative bg-white dark:bg-gray-800 rounded-3xl shadow-xl overflow-hidden border border-gray-100 dark:border-gray-700">
                <div className={`h-2 bg-gradient-to-r ${place.color}`}></div>
                <div className="p-6">
                  <div className={`inline-flex p-4 bg-gradient-to-br ${place.color} rounded-2xl shadow-lg mb-4 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}>
                    <place.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl text-gray-800 dark:text-white mb-2">{place.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed text-sm">
                    {place.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional Services */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            whileHover={{ scale: 1.02 }}
            className="group relative"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-3xl blur-xl opacity-0 group-hover:opacity-30 transition-opacity"></div>
            <div className="relative bg-gradient-to-br from-indigo-100 to-blue-100 dark:from-indigo-900/40 dark:to-blue-900/40 rounded-3xl shadow-xl p-10 border border-indigo-200 dark:border-indigo-800">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-4 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-2xl shadow-xl group-hover:scale-110 group-hover:rotate-6 transition-all">
                  <Sparkles className="w-12 h-12 text-white" />
                </div>
                <h3 className="text-3xl text-gray-800 dark:text-white">المهندسون</h3>
              </div>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-lg">
                مهندسون في مختلف المجالات يساهمون في تطوير القرية وتحديث بنيتها التحتية
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            whileHover={{ scale: 1.02 }}
            className="group relative"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-green-500 to-emerald-600 rounded-3xl blur-xl opacity-0 group-hover:opacity-30 transition-opacity"></div>
            <div className="relative bg-gradient-to-br from-green-100 to-emerald-100 dark:from-green-900/40 dark:to-emerald-900/40 rounded-3xl shadow-xl p-10 border border-green-200 dark:border-green-800">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-4 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl shadow-xl group-hover:scale-110 group-hover:rotate-6 transition-all">
                  <Hammer className="w-12 h-12 text-white" />
                </div>
                <h3 className="text-3xl text-gray-800 dark:text-white">المزارعون</h3>
              </div>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-lg">
                مزارعون مجتهدون يعتنون بالأرض ويوفرون المنتجات الزراعية الطازجة للقرية
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
