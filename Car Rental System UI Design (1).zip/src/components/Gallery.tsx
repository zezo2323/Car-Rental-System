import React from 'react';
import { motion } from 'motion/react';
import { Camera, Image as ImageIcon } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export default function Gallery() {
  const images = [
    {
      src: 'https://images.unsplash.com/photo-1751379250685-dadf0f214489?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFwZSUyMGZhcm0lMjBoYXJ2ZXN0fGVufDF8fHx8MTc2NDAyNzI3NXww&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'مزارع العنب',
    },
    {
      src: 'https://images.unsplash.com/photo-1698086032795-c8707f13f980?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGdyYXBlcyUyMHJhaXNpbnN8ZW58MXx8fHwxNzY0MDI3Mjc2fDA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'العنب الطازج',
    },
    {
      src: 'https://images.unsplash.com/photo-1747914873809-bc5f7c8a07a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMGFyYWJpYyUyMGFyY2hpdGVjdHVyZXxlbnwxfHx8fDE3NjQwMjcyNzV8MA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'العمارة التقليدية',
    },
    {
      src: 'https://images.unsplash.com/photo-1580849279061-0179c4ebf14e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pdHklMjBwZW9wbGUlMjB0b2dldGhlcnxlbnwxfHx8fDE3NjQwMTcwNTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'مجتمعنا',
    },
  ];

  return (
    <section className="py-32 px-6 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-3 mb-4">
            <Camera className="w-10 h-10 text-amber-600 dark:text-amber-400" />
            <h2 className="text-5xl text-gray-800 dark:text-white">معرض الصور</h2>
            <Camera className="w-10 h-10 text-amber-600 dark:text-amber-400" />
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 mt-4">
            لمحات من جمال قريتنا وحياتنا اليومية
          </p>
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: 100 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="h-1 bg-gradient-to-r from-amber-500 to-green-500 mx-auto rounded-full mt-4"
          />
        </motion.div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {images.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.6 }}
              whileHover={{ scale: 1.03, y: -5 }}
              className="group relative overflow-hidden rounded-3xl shadow-xl cursor-pointer"
            >
              <ImageWithFallback
                src={image.src}
                alt={image.title}
                className="w-full h-80 object-cover transform group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                <div className="flex items-center gap-3">
                  <ImageIcon className="w-6 h-6 text-white" />
                  <h3 className="text-2xl text-white">{image.title}</h3>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
