import { useState } from 'react';
import { motion } from 'motion/react';
import { Car, Plus, Edit, Trash2, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { mockCars } from '../lib/mock-data';
import { toast } from 'sonner@2.0.3';

export function CarsManagement() {
  const [cars, setCars] = useState(mockCars);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCars = cars.filter(car =>
    car.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    car.brand.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleToggleAvailability = (carId: string) => {
    setCars(cars.map(car =>
      car.id === carId ? { ...car, available: !car.available } : car
    ));
    toast.success('Car availability updated');
  };

  const handleDeleteCar = (carId: string) => {
    setCars(cars.filter(car => car.id !== carId));
    toast.success('Car deleted successfully');
  };

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-primary mb-2">Cars Management</h1>
          <p className="text-muted-foreground">Manage your car inventory</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Add New Car
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Car className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl">{cars.length}</p>
              <p className="text-xs text-muted-foreground">Total Cars</p>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <Car className="w-5 h-5 text-green-500" />
            </div>
            <div>
              <p className="text-2xl">{cars.filter(c => c.available).length}</p>
              <p className="text-xs text-muted-foreground">Available</p>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
              <Car className="w-5 h-5 text-red-500" />
            </div>
            <div>
              <p className="text-2xl">{cars.filter(c => !c.available).length}</p>
              <p className="text-xs text-muted-foreground">Rented</p>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
              <Car className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-2xl">${Math.round(cars.reduce((sum, c) => sum + c.pricePerDay, 0) / cars.length)}</p>
              <p className="text-xs text-muted-foreground">Avg Price/Day</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Search cars..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Cars Table */}
      <div className="rounded-2xl bg-card border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                <th className="px-6 py-4 text-left text-sm">Car</th>
                <th className="px-6 py-4 text-left text-sm">Category</th>
                <th className="px-6 py-4 text-left text-sm">Year</th>
                <th className="px-6 py-4 text-left text-sm">Price/Day</th>
                <th className="px-6 py-4 text-left text-sm">Specs</th>
                <th className="px-6 py-4 text-left text-sm">Status</th>
                <th className="px-6 py-4 text-left text-sm">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCars.map((car, index) => (
                <motion.tr
                  key={car.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-border hover:bg-muted/50 transition-colors"
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-16 h-12 rounded-lg overflow-hidden bg-muted">
                        <img
                          src={car.image}
                          alt={car.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <p className="text-sm">{car.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {car.brand} {car.model}
                        </p>
                      </div>
                    </div>
                  </td>

                  <td className="px-6 py-4">
                    <span className="inline-flex px-3 py-1 rounded-full text-xs bg-primary/10 text-primary capitalize">
                      {car.category}
                    </span>
                  </td>

                  <td className="px-6 py-4">
                    <span className="text-sm">{car.year}</span>
                  </td>

                  <td className="px-6 py-4">
                    <span className="text-sm text-primary">${car.pricePerDay}</span>
                  </td>

                  <td className="px-6 py-4">
                    <div className="text-xs text-muted-foreground space-y-1">
                      <p>{car.seats} seats • {car.transmission}</p>
                      <p>{car.fuelType}</p>
                    </div>
                  </td>

                  <td className="px-6 py-4">
                    <button
                      onClick={() => handleToggleAvailability(car.id)}
                      className={`inline-flex px-3 py-1 rounded-full text-xs ${
                        car.available
                          ? 'bg-green-500/10 text-green-500'
                          : 'bg-red-500/10 text-red-500'
                      }`}
                    >
                      {car.available ? 'Available' : 'Rented'}
                    </button>
                  </td>

                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteCar(car.id)}
                        className="hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredCars.length === 0 && (
        <div className="text-center py-12">
          <Car className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="mb-2">No cars found</h3>
          <p className="text-muted-foreground">Try adjusting your search</p>
        </div>
      )}
    </div>
  );
}
