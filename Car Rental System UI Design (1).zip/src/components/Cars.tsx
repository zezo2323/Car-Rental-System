import { useState } from 'react';
import { motion } from 'motion/react';
import {
  Car as CarIcon,
  Users,
  Fuel,
  Settings,
  Check,
  Calendar,
} from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardFooter, CardHeader } from './ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { cars } from '../lib/data';
import { Car } from '../types';
import { useAuth } from '../lib/auth-context';
import { ImageWithFallback } from './figma/ImageWithFallback';

const categories = [
  { id: 'all', label: 'الكل' },
  { id: 'sedan', label: 'سيدان' },
  { id: 'suv', label: 'دفع رباعي' },
  { id: 'sports', label: 'رياضية' },
  { id: 'luxury', label: 'فاخرة' },
];

export function Cars() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedCar, setSelectedCar] = useState<Car | null>(null);
  const [showBookingDialog, setShowBookingDialog] = useState(false);
  const { user } = useAuth();

  const filteredCars =
    selectedCategory === 'all'
      ? cars
      : cars.filter((car) => car.category === selectedCategory);

  const handleBooking = (car: Car) => {
    setSelectedCar(car);
    setShowBookingDialog(true);
  };

  return (
    <section id="cars" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="mb-4">اختر سيارتك المفضلة</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            لدينا مجموعة متنوعة من السيارات التي تناسب جميع احتياجاتك وميزانيتك
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              onClick={() => setSelectedCategory(category.id)}
              className="px-6"
            >
              {category.label}
            </Button>
          ))}
        </motion.div>

        {/* Cars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCars.map((car, index) => (
            <motion.div
              key={car.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="overflow-hidden group hover:shadow-xl transition-shadow duration-300">
                <CardHeader className="p-0 relative">
                  <div className="aspect-video overflow-hidden">
                    <ImageWithFallback
                      src={car.image}
                      alt={car.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="absolute top-4 right-4 flex gap-2">
                    {car.available ? (
                      <Badge className="bg-secondary">متاحة</Badge>
                    ) : (
                      <Badge variant="destructive">محجوزة</Badge>
                    )}
                    <Badge variant="outline" className="bg-background/90">
                      {car.year}
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="p-6">
                  <div className="mb-4">
                    <h3 className="mb-1">{car.name}</h3>
                    <p className="text-muted-foreground">{car.brand}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Users className="w-4 h-4" />
                      <span>{car.seats} مقاعد</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Settings className="w-4 h-4" />
                      <span>{car.transmission === 'automatic' ? 'أوتوماتيك' : 'يدوي'}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Fuel className="w-4 h-4" />
                      <span>{car.fuel}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CarIcon className="w-4 h-4" />
                      <span>{car.category}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {car.features.slice(0, 3).map((feature, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-1 text-xs text-muted-foreground"
                      >
                        <Check className="w-3 h-3 text-primary" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <div>
                      <p className="text-2xl text-primary">{car.pricePerDay} ر.س</p>
                      <p className="text-xs text-muted-foreground">لليوم الواحد</p>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="p-6 pt-0">
                  <Button
                    className="w-full"
                    onClick={() => handleBooking(car)}
                    disabled={!car.available}
                  >
                    <Calendar className="ml-2 w-4 h-4" />
                    احجز الآن
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Booking Dialog */}
        <Dialog open={showBookingDialog} onOpenChange={setShowBookingDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>حجز سيارة</DialogTitle>
              <DialogDescription>
                {selectedCar && `احجز ${selectedCar.name} الآن`}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {!user ? (
                <p className="text-center text-muted-foreground py-4">
                  يرجى تسجيل الدخول أولاً لإتمام عملية الحجز
                </p>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="start-date">تاريخ البداية</Label>
                    <Input id="start-date" type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end-date">تاريخ النهاية</Label>
                    <Input id="end-date" type="date" />
                  </div>
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex justify-between mb-2">
                      <span>السعر اليومي:</span>
                      <span>{selectedCar?.pricePerDay} ر.س</span>
                    </div>
                    <div className="flex justify-between">
                      <span>المجموع:</span>
                      <span className="text-primary">
                        {selectedCar?.pricePerDay} ر.س
                      </span>
                    </div>
                  </div>
                  <Button className="w-full">تأكيد الحجز</Button>
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
}
