import { motion } from 'motion/react';
import { Search, Calendar, Car, CheckCircle } from 'lucide-react';

const steps = [
  {
    icon: Search,
    title: 'اختر سيارتك',
    description: 'تصفح مجموعتنا الواسعة من السيارات واختر ما يناسبك',
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
  {
    icon: Calendar,
    title: 'حدد التاريخ',
    description: 'اختر تاريخ البداية والنهاية لفترة الإيجار',
    color: 'text-secondary',
    bgColor: 'bg-secondary/10',
  },
  {
    icon: CheckCircle,
    title: 'أكمل الحجز',
    description: 'أدخل بياناتك وأكمل عملية الدفع بأمان',
    color: 'text-accent',
    bgColor: 'bg-accent/10',
  },
  {
    icon: Car,
    title: 'استلم واستمتع',
    description: 'استلم سيارتك وانطلق في رحلتك بكل راحة',
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
];

export function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="mb-4">كيف يعمل النظام</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            احجز سيارتك في أربع خطوات بسيطة وسريعة
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {/* Connection Lines for Desktop */}
          <div className="hidden lg:block absolute top-1/4 left-0 right-0 h-0.5 bg-border -z-10" />

          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="relative"
            >
              <div className="bg-card border border-border rounded-2xl p-6 hover:shadow-xl transition-all duration-300 group">
                {/* Step Number */}
                <motion.div
                  className="absolute -top-4 right-6 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center shadow-lg"
                  whileHover={{ scale: 1.2, rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  {index + 1}
                </motion.div>

                {/* Icon */}
                <motion.div
                  className={`inline-flex items-center justify-center w-16 h-16 rounded-xl ${step.bgColor} ${step.color} mb-4 group-hover:scale-110 transition-transform`}
                  whileHover={{ rotate: [0, -10, 10, -10, 0] }}
                  transition={{ duration: 0.5 }}
                >
                  <step.icon className="w-8 h-8" />
                </motion.div>

                {/* Content */}
                <h3 className="mb-2">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>

              {/* Arrow for Mobile */}
              {index < steps.length - 1 && (
                <div className="lg:hidden flex justify-center my-4">
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-primary"
                  >
                    <svg
                      className="w-6 h-6 rotate-90"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </motion.div>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <p className="text-muted-foreground mb-6">
            جاهز للبدء؟ احجز سيارتك الآن واستمتع بأفضل تجربة تأجير
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-primary text-primary-foreground px-8 py-3 rounded-lg hover:shadow-lg transition-shadow"
          >
            ابدأ الحجز الآن
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
