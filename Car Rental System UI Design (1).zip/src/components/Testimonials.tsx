import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { testimonials } from '../lib/data';

export function Testimonials() {
  return (
    <section id="testimonials" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="mb-4">آراء عملائنا</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            اكتشف تجارب عملائنا الراضين وما يقولونه عن خدماتنا
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full hover:shadow-xl transition-shadow duration-300 group">
                <CardContent className="p-6">
                  {/* Quote Icon */}
                  <motion.div
                    className="text-primary/20 mb-4"
                    whileHover={{ scale: 1.2, rotate: 180 }}
                    transition={{ duration: 0.5 }}
                  >
                    <Quote className="w-10 h-10" />
                  </motion.div>

                  {/* Rating */}
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, scale: 0 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.1 + i * 0.05 }}
                      >
                        <Star
                          className={`w-5 h-5 ${
                            i < testimonial.rating
                              ? 'fill-primary text-primary'
                              : 'text-muted'
                          }`}
                        />
                      </motion.div>
                    ))}
                  </div>

                  {/* Comment */}
                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    "{testimonial.comment}"
                  </p>

                  {/* Author */}
                  <div className="flex items-center gap-3 pt-4 border-t border-border">
                    <Avatar>
                      <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                      <AvatarFallback>
                        {testimonial.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h4>{testimonial.name}</h4>
                      <p className="text-xs text-muted-foreground">
                        {new Date(testimonial.date).toLocaleDateString('ar-SA', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Overall Rating Summary */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl p-8 text-center"
        >
          <div className="max-w-2xl mx-auto">
            <motion.div
              className="text-6xl mb-4"
              whileHover={{ scale: 1.1 }}
            >
              ⭐ 4.9
            </motion.div>
            <h3 className="mb-2">تقييم ممتاز من عملائنا</h3>
            <p className="text-muted-foreground">
              بناءً على أكثر من 2,500 تقييم من عملائنا الكرام
            </p>
            <div className="flex justify-center gap-2 mt-6">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className="w-8 h-8 fill-primary text-primary"
                />
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
