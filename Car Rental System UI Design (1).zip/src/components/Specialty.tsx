import React from 'react';
import { motion } from 'motion/react';
import { Grape, Award, Sun, Droplets, TrendingUp, Leaf } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export default function Specialty() {
  const qualities = [
    {
      icon: Sun,
      title: 'مناخ مثالي',
      description: 'أشعة الشمس الوفيرة والطقس المناسب لزراعة أجود أنواع العنب',
      color: 'from-yellow-500 to-orange-600',
    },
    {
      icon: Droplets,
      title: 'تربة خصبة',
      description: 'أرض غنية بالمعادن تمنح العنب مذاقاً فريداً ونوعية ممتازة',
      color: 'from-blue-500 to-cyan-600',
    },
    {
      icon: TrendingUp,
      title: 'جودة عالية',
      description: 'منتجات طبيعية 100% يتم تجفيفها وتعبئتها وفق أعلى المعايير',
      color: 'from-green-500 to-emerald-600',
    },
  ];

  return (
    <section id="specialty" className="py-32 px-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-white to-green-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900"></div>
      <div className="absolute top-10 right-10 w-96 h-96 bg-purple-300 dark:bg-purple-900/30 rounded-full blur-3xl opacity-30"></div>
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-green-300 dark:bg-green-900/30 rounded-full blur-3xl opacity-30"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-3 mb-4">
            <Grape className="w-12 h-12 text-purple-600 dark:text-purple-400" />
            <h2 className="text-5xl text-gray-800 dark:text-white">تخصصنا الرئيسي</h2>
            <Grape className="w-12 h-12 text-purple-600 dark:text-purple-400" />
          </div>
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: 100 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="h-1 bg-gradient-to-r from-purple-500 to-green-500 mx-auto rounded-full"
          />
        </motion.div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative group order-2 lg:order-1"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-green-500 rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity"></div>
            <div className="relative overflow-hidden rounded-3xl shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1751379250685-dadf0f214489?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFwZSUyMGZhcm0lMjBoYXJ2ZXN0fGVufDF8fHx8MTc2NDAyNzI3NXww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Grape farm"
                className="w-full h-[500px] object-cover transform group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute top-6 right-6">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                  className="p-4 bg-yellow-400 rounded-full shadow-xl"
                >
                  <Award className="w-10 h-10 text-white" />
                </motion.div>
              </div>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="order-1 lg:order-2"
          >
            <div className="flex items-center gap-3 mb-6">
              <Grape className="w-16 h-16 text-purple-600 dark:text-purple-400" />
              <h3 className="text-4xl text-gray-800 dark:text-white">
                زراعة العنب وإنتاج الزبيب
              </h3>
            </div>
            <p className="text-xl text-gray-600 dark:text-gray-300 leading-relaxed mb-8">
              تشتهر قرية شنراق الخير بزراعة العنب عالي الجودة وإنتاج الزبيب الفاخر.
              تمتد مزارع العنب على مساحات واسعة وتستفيد من المناخ المثالي والتربة الخصبة.
            </p>

            {/* Qualities */}
            <div className="space-y-4">
              {qualities.map((quality, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2, duration: 0.6 }}
                  whileHover={{ scale: 1.03, x: 10 }}
                  className="group flex items-start gap-4 p-5 bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-xl transition-all border border-gray-100 dark:border-gray-700"
                >
                  <div className={`p-3 bg-gradient-to-br ${quality.color} rounded-xl shadow-md group-hover:scale-110 group-hover:rotate-6 transition-all`}>
                    <quality.icon className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl text-gray-800 dark:text-white mb-1">{quality.title}</h4>
                    <p className="text-gray-600 dark:text-gray-300">{quality.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Stats Bar */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-green-600 rounded-3xl blur-xl opacity-50"></div>
          <div className="relative bg-gradient-to-r from-purple-600 to-green-600 rounded-3xl shadow-2xl p-10">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center text-white">
              {[
                { emoji: '🍇', title: 'أجود الأنواع', subtitle: 'عنب ممتاز' },
                { emoji: '🌿', title: 'طبيعي 100%', subtitle: 'بدون إضافات' },
                { emoji: '⭐', title: 'تراث عريق', subtitle: 'خبرة أجيال' },
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.1, y: -5 }}
                  className="cursor-pointer"
                >
                  <div className="text-6xl mb-3">{stat.emoji}</div>
                  <p className="text-2xl mb-1">{stat.title}</p>
                  <p className="text-purple-100">{stat.subtitle}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Additional Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
          {[
            {
              icon: Leaf,
              emoji: '🌾',
              title: 'موسم الحصاد',
              description:
                'يبدأ موسم قطف العنب في أواخر الصيف، حيث يجتمع أهل القرية في جو من الفرح والتعاون لجني المحصول',
            },
            {
              icon: TrendingUp,
              emoji: '📦',
              title: 'التسويق والبيع',
              description:
                'يتم تسويق الزبيب في الأسواق المحلية والإقليمية، ونفخر بسمعتنا الطيبة في جودة منتجاتنا',
            },
          ].map((info, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.8 }}
              whileHover={{ y: -5, scale: 1.02 }}
              className="group relative"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-200 to-green-200 dark:from-purple-900/20 dark:to-green-900/20 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative bg-white dark:bg-gray-800 rounded-3xl shadow-xl p-8 border border-gray-100 dark:border-gray-700">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-4xl">{info.emoji}</span>
                  <h4 className="text-2xl text-gray-800 dark:text-white">{info.title}</h4>
                </div>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{info.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
