
  # Car Rental System UI Design

  This is a code bundle for Car Rental System UI Design. The original project is available at https://www.figma.com/design/jItQapxnMNL9J5sLMrLFtf/Car-Rental-System-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  