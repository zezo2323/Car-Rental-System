import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  LayoutDashboard,
  Users,
  Image as ImageIcon,
  MessageSquare,
  MapPin,
  Grape,
  Settings,
  ArrowRight,
  Plus,
  Edit,
  Trash2,
  Eye,
  BarChart3,
  TrendingUp,
  Building2,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface AdminDashboardProps {
  onBackToSite: () => void;
}

export default function AdminDashboard({ onBackToSite }: AdminDashboardProps) {
  const { user, logout } = useAuth();
  const [activeSection, setActiveSection] = useState<'overview' | 'places' | 'community' | 'gallery' | 'messages'>('overview');

  const stats = [
    { label: 'إجمالي الزوار', value: '2,847', icon: Users, color: 'from-blue-500 to-cyan-600', change: '+12%' },
    { label: 'الأماكن المسجلة', value: '24', icon: MapPin, color: 'from-green-500 to-emerald-600', change: '+3' },
    { label: 'أفراد المجتمع', value: '156', icon: Users, color: 'from-purple-500 to-violet-600', change: '+8' },
    { label: 'الصور', value: '89', icon: ImageIcon, color: 'from-amber-500 to-orange-600', change: '+15' },
  ];

  const menuItems = [
    { id: 'overview', label: 'لوحة التحكم', icon: LayoutDashboard },
    { id: 'places', label: 'إدارة الأماكن', icon: Building2 },
    { id: 'community', label: 'المجتمع', icon: Users },
    { id: 'gallery', label: 'معرض الصور', icon: ImageIcon },
    { id: 'messages', label: 'الرسائل', icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      {/* Top Navigation */}
      <nav className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onBackToSite}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-green-500 text-white rounded-xl shadow-lg hover:shadow-xl transition-all"
            >
              <ArrowRight className="w-5 h-5" />
              <span>العودة للموقع</span>
            </motion.button>
            <h1 className="text-2xl text-gray-800 dark:text-white">لوحة التحكم - صُنّاع الخير</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-gray-600 dark:text-gray-400">مرحباً</p>
              <p className="text-gray-800 dark:text-white">{user?.name}</p>
            </div>
            <button
              onClick={logout}
              className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-xl transition-colors"
            >
              تسجيل خروج
            </button>
          </div>
        </div>
      </nav>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 min-h-[calc(100vh-73px)] p-4">
          <nav className="space-y-2">
            {menuItems.map((item) => (
              <motion.button
                key={item.id}
                whileHover={{ x: -5 }}
                onClick={() => setActiveSection(item.id as any)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  activeSection === item.id
                    ? 'bg-gradient-to-r from-amber-500 to-green-500 text-white shadow-lg'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.label}</span>
              </motion.button>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {activeSection === 'overview' && (
            <div className="space-y-8">
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {stats.map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ y: -5, scale: 1.02 }}
                    className="relative group"
                  >
                    <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} rounded-3xl blur-xl opacity-20 group-hover:opacity-40 transition-opacity`}></div>
                    <div className="relative bg-white dark:bg-gray-800 rounded-3xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
                      <div className="flex items-center justify-between mb-4">
                        <div className={`p-3 bg-gradient-to-br ${stat.color} rounded-xl shadow-md`}>
                          <stat.icon className="w-6 h-6 text-white" />
                        </div>
                        <span className="text-green-600 dark:text-green-400 text-sm flex items-center gap-1">
                          <TrendingUp className="w-4 h-4" />
                          {stat.change}
                        </span>
                      </div>
                      <p className="text-3xl text-gray-800 dark:text-white mb-1">{stat.value}</p>
                      <p className="text-gray-600 dark:text-gray-400">{stat.label}</p>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Quick Actions */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-white dark:bg-gray-800 rounded-3xl shadow-lg p-6 border border-gray-100 dark:border-gray-700"
              >
                <h3 className="text-2xl text-gray-800 dark:text-white mb-6 flex items-center gap-2">
                  <BarChart3 className="w-6 h-6 text-amber-500" />
                  إجراءات سريعة
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { icon: Plus, label: 'إضافة مكان جديد', color: 'from-blue-500 to-cyan-600' },
                    { icon: Users, label: 'إضافة عضو للمجتمع', color: 'from-purple-500 to-violet-600' },
                    { icon: ImageIcon, label: 'رفع صور جديدة', color: 'from-amber-500 to-orange-600' },
                  ].map((action, index) => (
                    <motion.button
                      key={index}
                      whileHover={{ scale: 1.05, y: -5 }}
                      whileTap={{ scale: 0.95 }}
                      className="flex items-center gap-3 p-4 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-600 rounded-2xl hover:shadow-lg transition-all border border-gray-200 dark:border-gray-600"
                    >
                      <div className={`p-3 bg-gradient-to-br ${action.color} rounded-xl shadow-md`}>
                        <action.icon className="w-5 h-5 text-white" />
                      </div>
                      <span className="text-gray-800 dark:text-white">{action.label}</span>
                    </motion.button>
                  ))}
                </div>
              </motion.div>

              {/* Recent Activity */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="bg-white dark:bg-gray-800 rounded-3xl shadow-lg p-6 border border-gray-100 dark:border-gray-700"
              >
                <h3 className="text-2xl text-gray-800 dark:text-white mb-6">النشاط الأخير</h3>
                <div className="space-y-4">
                  {[
                    { action: 'تم إضافة مكان جديد: مسجد النور', time: 'منذ ساعتين', icon: Building2, color: 'text-green-600' },
                    { action: 'تم رفع 5 صور جديدة للمعرض', time: 'منذ 4 ساعات', icon: ImageIcon, color: 'text-amber-600' },
                    { action: 'رسالة جديدة من أحمد المزارع', time: 'منذ 6 ساعات', icon: MessageSquare, color: 'text-blue-600' },
                  ].map((activity, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                    >
                      <div className={`p-2 bg-white dark:bg-gray-800 rounded-lg ${activity.color}`}>
                        <activity.icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <p className="text-gray-800 dark:text-white">{activity.action}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          )}

          {activeSection === 'places' && (
            <PlacesManagement />
          )}

          {activeSection === 'community' && (
            <CommunityManagement />
          )}

          {activeSection === 'gallery' && (
            <GalleryManagement />
          )}

          {activeSection === 'messages' && (
            <MessagesManagement />
          )}
        </main>
      </div>
    </div>
  );
}

function PlacesManagement() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl text-gray-800 dark:text-white">إدارة الأماكن</h2>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-green-500 text-white rounded-xl shadow-lg"
        >
          <Plus className="w-5 h-5" />
          <span>إضافة مكان جديد</span>
        </motion.button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          { name: 'مسجد النور', type: 'مسجد', visitors: 250 },
          { name: 'مدرسة الأمل', type: 'مدرسة', visitors: 180 },
          { name: 'صيدلية الشفاء', type: 'صيدلية', visitors: 95 },
        ].map((place, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700"
          >
            <h3 className="text-xl text-gray-800 dark:text-white mb-2">{place.name}</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">{place.type}</p>
            <p className="text-sm text-gray-500 dark:text-gray-500 mb-4">زوار: {place.visitors}</p>
            <div className="flex gap-2">
              <button className="flex-1 px-3 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors flex items-center justify-center gap-2">
                <Edit className="w-4 h-4" />
                <span>تعديل</span>
              </button>
              <button className="px-3 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function CommunityManagement() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl text-gray-800 dark:text-white">إدارة المجتمع</h2>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-violet-600 text-white rounded-xl shadow-lg"
        >
          <Plus className="w-5 h-5" />
          <span>إضافة عضو جديد</span>
        </motion.button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700">
        <table className="w-full">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th className="px-6 py-3 text-right text-gray-700 dark:text-gray-300">الاسم</th>
              <th className="px-6 py-3 text-right text-gray-700 dark:text-gray-300">المهنة</th>
              <th className="px-6 py-3 text-right text-gray-700 dark:text-gray-300">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {[
              { name: 'أحمد المزارع', profession: 'مزارع عنب' },
              { name: 'فاطمة المعلمة', profession: 'معلمة لغة عربية' },
              { name: 'خالد النجار', profession: 'نجار وحرفي' },
            ].map((member, index) => (
              <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                <td className="px-6 py-4 text-gray-800 dark:text-white">{member.name}</td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-400">{member.profession}</td>
                <td className="px-6 py-4">
                  <div className="flex gap-2">
                    <button className="p-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="p-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function GalleryManagement() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl text-gray-800 dark:text-white">إدارة معرض الصور</h2>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-xl shadow-lg"
        >
          <Plus className="w-5 h-5" />
          <span>رفع صور جديدة</span>
        </motion.button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {[...Array(8)].map((_, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            className="relative group aspect-square bg-gray-200 dark:bg-gray-700 rounded-2xl overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-amber-500 to-green-500 opacity-20"></div>
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/50 transition-opacity">
              <div className="flex gap-2">
                <button className="p-2 bg-white rounded-lg hover:scale-110 transition-transform">
                  <Eye className="w-5 h-5 text-gray-800" />
                </button>
                <button className="p-2 bg-red-500 rounded-lg hover:scale-110 transition-transform">
                  <Trash2 className="w-5 h-5 text-white" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function MessagesManagement() {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl text-gray-800 dark:text-white">الرسائل الواردة</h2>
      
      <div className="space-y-4">
        {[
          { name: 'محمد أحمد', email: 'mohamed@example.com', message: 'أريد الاستفسار عن...', time: 'منذ ساعة', unread: true },
          { name: 'سارة علي', email: 'sara@example.com', message: 'شكراً على الموقع الرائع', time: 'منذ 3 ساعات', unread: true },
          { name: 'عبدالله خالد', email: 'abdullah@example.com', message: 'هل يمكن إضافة...', time: 'منذ يوم', unread: false },
        ].map((msg, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-lg border ${
              msg.unread
                ? 'border-amber-300 dark:border-amber-700'
                : 'border-gray-100 dark:border-gray-700'
            }`}
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="text-xl text-gray-800 dark:text-white">{msg.name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{msg.email}</p>
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400">{msg.time}</span>
            </div>
            <p className="text-gray-600 dark:text-gray-300 mb-4">{msg.message}</p>
            <button className="px-4 py-2 bg-gradient-to-r from-amber-500 to-green-500 text-white rounded-lg hover:shadow-lg transition-all">
              عرض الرسالة الكاملة
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
