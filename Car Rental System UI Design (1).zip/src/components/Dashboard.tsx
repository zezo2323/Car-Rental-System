import { motion } from 'motion/react';
import { Car, DollarSign, Users, Calendar, TrendingUp, Clock } from 'lucide-react';
import { Button } from './ui/button';
import { mockCars, mockRentals, mockUsers } from '../lib/mock-data';

interface DashboardProps {
  onNavigate: (page: string, data?: any) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const availableCars = mockCars.filter(car => car.available).length;
  const rentedCars = mockCars.filter(car => !car.available).length;
  const activeRentals = mockRentals.filter(r => r.status === 'active').length;
  const totalRevenue = mockRentals.reduce((sum, r) => sum + r.totalAmount, 0);
  const totalUsers = mockUsers.filter(u => u.role === 'user').length;

  const stats = [
    {
      label: 'Available Cars',
      value: availableCars,
      icon: Car,
      color: 'bg-primary/10 text-primary',
      trend: '+12%',
    },
    {
      label: 'Rented Cars',
      value: rentedCars,
      icon: Calendar,
      color: 'bg-secondary/10 text-secondary',
      trend: '+8%',
    },
    {
      label: 'Total Revenue',
      value: `$${totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'bg-accent/10 text-accent',
      trend: '+24%',
    },
    {
      label: 'Active Users',
      value: totalUsers,
      icon: Users,
      color: 'bg-purple-500/10 text-purple-500',
      trend: '+16%',
    },
  ];

  const recentRentals = mockRentals.slice(0, 5);

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-primary mb-2">Admin Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's what's happening today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-6 rounded-2xl bg-card border border-border hover:shadow-lg transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-xl ${stat.color} flex items-center justify-center`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <div className="flex items-center gap-1 text-xs text-green-500">
                <TrendingUp className="w-3 h-3" />
                {stat.trend}
              </div>
            </div>
            <div className="space-y-1">
              <h3>{stat.value}</h3>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Rentals */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="p-6 rounded-2xl bg-card border border-border"
        >
          <div className="flex items-center justify-between mb-6">
            <h3>Recent Rentals</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('rentals')}
            >
              View All
            </Button>
          </div>
          <div className="space-y-4">
            {recentRentals.map((rental) => {
              const car = mockCars.find(c => c.id === rental.carId);
              const user = mockUsers.find(u => u.id === rental.userId);
              return (
                <div key={rental.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted/50 transition-colors">
                  <div className="w-12 h-12 rounded-lg overflow-hidden bg-muted">
                    {car && (
                      <img src={car.image} alt={car.name} className="w-full h-full object-cover" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="truncate">{car?.name}</p>
                    <p className="text-xs text-muted-foreground">{user?.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-primary">${rental.totalAmount}</p>
                    <p className="text-xs text-muted-foreground">{rental.totalDays}d</p>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Popular Cars */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="p-6 rounded-2xl bg-card border border-border"
        >
          <div className="flex items-center justify-between mb-6">
            <h3>Popular Cars</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('cars')}
            >
              View All
            </Button>
          </div>
          <div className="space-y-4">
            {mockCars.slice(0, 5).map((car, index) => (
              <div key={car.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted/50 transition-colors">
                <div className="w-12 h-12 rounded-lg overflow-hidden bg-muted">
                  <img src={car.image} alt={car.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="truncate">{car.name}</p>
                  <p className="text-xs text-muted-foreground">{car.category}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-primary">${car.pricePerDay}/day</p>
                  <div className={`text-xs ${car.available ? 'text-green-500' : 'text-red-500'}`}>
                    {car.available ? 'Available' : 'Rented'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Quick Action Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button
          onClick={() => onNavigate('cars')}
          className="h-24 text-lg"
          variant="outline"
        >
          <Car className="w-6 h-6 mr-2" />
          Manage Cars
        </Button>
        <Button
          onClick={() => onNavigate('rentals')}
          className="h-24 text-lg"
          variant="outline"
        >
          <Calendar className="w-6 h-6 mr-2" />
          View Rentals
        </Button>
        <Button
          onClick={() => onNavigate('users')}
          className="h-24 text-lg"
          variant="outline"
        >
          <Users className="w-6 h-6 mr-2" />
          Manage Users
        </Button>
      </div>
    </div>
  );
}
