import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Calendar, Clock, DollarSign, Car as CarIcon, ArrowLeft, Check } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { useAuth } from '../lib/auth-context';
import { Car } from '../lib/mock-data';
import { toast } from 'sonner@2.0.3';

interface RentalPageProps {
  car: Car;
  onNavigate: (page: string, data?: any) => void;
}

export function RentalPage({ car, onNavigate }: RentalPageProps) {
  const { user } = useAuth();
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [startTime, setStartTime] = useState('10:00');
  const [endTime, setEndTime] = useState('10:00');
  
  const [totalDays, setTotalDays] = useState(0);
  const [subtotal, setSubtotal] = useState(0);
  const [tax, setTax] = useState(0);
  const [total, setTotal] = useState(0);

  const TAX_RATE = 0.15; // 15% tax

  useEffect(() => {
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; // +1 to include both days
      
      if (diffDays > 0) {
        setTotalDays(diffDays);
        const sub = diffDays * car.pricePerDay;
        const taxAmount = sub * TAX_RATE;
        setSubtotal(sub);
        setTax(taxAmount);
        setTotal(sub + taxAmount);
      }
    }
  }, [startDate, endDate, car.pricePerDay]);

  const handleConfirmBooking = () => {
    if (!startDate || !endDate) {
      toast.error('Please select start and end dates');
      return;
    }

    if (new Date(startDate) > new Date(endDate)) {
      toast.error('End date must be after start date');
      return;
    }

    const rental = {
      id: `R${Date.now()}`,
      carId: car.id,
      userId: user!.id,
      startDate: `${startDate} ${startTime}`,
      endDate: `${endDate} ${endTime}`,
      totalDays,
      subtotal,
      tax,
      totalAmount: total,
      status: 'active' as const,
      createdAt: new Date().toISOString(),
    };

    toast.success('Booking confirmed!');
    onNavigate('invoice', { rental, car });
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => onNavigate('cars-list')}
        className="mb-4"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Cars
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Side - Car Details */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          <div>
            <h1 className="text-primary mb-2">Book Your Ride</h1>
            <p className="text-muted-foreground">Complete the booking details below</p>
          </div>

          {/* Car Card */}
          <div className="rounded-2xl bg-card border border-border overflow-hidden">
            <div className="h-64 overflow-hidden bg-muted">
              <img
                src={car.image}
                alt={car.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-6 space-y-4">
              <div>
                <h3 className="mb-1">{car.name}</h3>
                <p className="text-muted-foreground">{car.brand} {car.model} • {car.year}</p>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {car.features.map((feature) => (
                  <span
                    key={feature}
                    className="flex items-center gap-1 px-3 py-1 rounded-lg bg-muted text-sm"
                  >
                    <Check className="w-3 h-3 text-primary" />
                    {feature}
                  </span>
                ))}
              </div>

              <div className="pt-4 border-t border-border">
                <div className="text-3xl text-primary">${car.pricePerDay}</div>
                <p className="text-sm text-muted-foreground">per day</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Right Side - Booking Form */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          <div className="rounded-2xl bg-card border border-border p-6 space-y-6">
            <h3>Rental Details</h3>

            {/* Date Selection */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm">Start Date</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm">End Date</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    min={startDate || new Date().toISOString().split('T')[0]}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>

            {/* Time Selection */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm">Pickup Time</label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm">Return Time</label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>

            {/* Price Breakdown */}
            {totalDays > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="pt-6 border-t border-border space-y-3"
              >
                <h4 className="mb-4">Price Breakdown</h4>
                
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Rental Duration</span>
                  <span>{totalDays} {totalDays === 1 ? 'day' : 'days'}</span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Price per day</span>
                  <span>${car.pricePerDay}</span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tax (15%)</span>
                  <span>${tax.toFixed(2)}</span>
                </div>

                <div className="pt-3 border-t border-border flex justify-between">
                  <span>Total Amount</span>
                  <span className="text-2xl text-primary">${total.toFixed(2)}</span>
                </div>
              </motion.div>
            )}

            <Button
              onClick={handleConfirmBooking}
              className="w-full h-12"
              size="lg"
              disabled={!startDate || !endDate || totalDays <= 0}
            >
              <DollarSign className="w-5 h-5 mr-2" />
              Confirm Booking
            </Button>
          </div>

          {/* Customer Info */}
          <div className="rounded-2xl bg-muted/50 border border-border p-6">
            <h4 className="mb-4">Customer Information</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Name:</span>
                <span>{user?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Email:</span>
                <span>{user?.email}</span>
              </div>
              {user?.phone && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Phone:</span>
                  <span>{user.phone}</span>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
