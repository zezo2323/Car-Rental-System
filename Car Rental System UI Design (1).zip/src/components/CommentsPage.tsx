import { useState } from 'react';
import { motion } from 'motion/react';
import { Star, MessageSquare, Reply, Trash2, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { useAuth } from '../lib/auth-context';
import { mockComments, mockCars } from '../lib/mock-data';
import { toast } from 'sonner@2.0.3';

export function CommentsPage() {
  const { user, isAdmin } = useAuth();
  const [comments, setComments] = useState(mockComments);
  const [replyText, setReplyText] = useState<{ [key: string]: string }>({});
  const [newComment, setNewComment] = useState({
    carId: '',
    rating: 5,
    comment: '',
  });

  const handleReply = (commentId: string) => {
    const reply = replyText[commentId]?.trim();
    if (!reply) {
      toast.error('Please enter a reply');
      return;
    }

    setComments(comments.map(c =>
      c.id === commentId ? { ...c, adminReply: reply } : c
    ));
    setReplyText({ ...replyText, [commentId]: '' });
    toast.success('Reply added successfully');
  };

  const handleDelete = (commentId: string) => {
    setComments(comments.filter(c => c.id !== commentId));
    toast.success('Comment deleted');
  };

  const handleSubmitComment = () => {
    if (!newComment.carId || !newComment.comment.trim()) {
      toast.error('Please select a car and write a comment');
      return;
    }

    const comment = {
      id: `C${Date.now()}`,
      userId: user!.id,
      userName: user!.name,
      carId: newComment.carId,
      rating: newComment.rating,
      comment: newComment.comment,
      date: new Date().toISOString().split('T')[0],
    };

    setComments([comment, ...comments]);
    setNewComment({ carId: '', rating: 5, comment: '' });
    toast.success('Comment posted successfully');
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-primary mb-2">Customer Reviews</h1>
        <p className="text-muted-foreground">
          {isAdmin ? 'Manage customer feedback and reviews' : 'Share your experience with our cars'}
        </p>
      </div>

      {/* Add New Comment (Users only) */}
      {!isAdmin && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-6 rounded-2xl bg-card border border-border space-y-4"
        >
          <h3>Write a Review</h3>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm">Select Car</label>
              <select
                value={newComment.carId}
                onChange={(e) => setNewComment({ ...newComment, carId: e.target.value })}
                className="w-full px-4 py-2 rounded-xl bg-background border border-border"
              >
                <option value="">Choose a car...</option>
                {mockCars.map((car) => (
                  <option key={car.id} value={car.id}>
                    {car.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm">Rating</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    key={rating}
                    onClick={() => setNewComment({ ...newComment, rating })}
                    className="transition-transform hover:scale-110"
                  >
                    <Star
                      className={`w-8 h-8 ${
                        rating <= newComment.rating
                          ? 'fill-yellow-500 text-yellow-500'
                          : 'text-muted-foreground'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm">Your Review</label>
              <textarea
                value={newComment.comment}
                onChange={(e) => setNewComment({ ...newComment, comment: e.target.value })}
                placeholder="Share your experience..."
                className="w-full min-h-24 px-4 py-3 rounded-xl bg-background border border-border resize-none"
              />
            </div>

            <Button onClick={handleSubmitComment} className="w-full">
              <Send className="w-4 h-4 mr-2" />
              Post Review
            </Button>
          </div>
        </motion.div>
      )}

      {/* Comments List */}
      <div className="space-y-4">
        {comments.map((comment, index) => {
          const car = mockCars.find(c => c.id === comment.carId);
          
          return (
            <motion.div
              key={comment.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-6 rounded-2xl bg-card border border-border space-y-4"
            >
              {/* Comment Header */}
              <div className="flex items-start justify-between">
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-lg text-primary">{comment.userName.charAt(0)}</span>
                  </div>
                  <div>
                    <h4>{comment.userName}</h4>
                    <p className="text-sm text-muted-foreground">{comment.date}</p>
                  </div>
                </div>

                {isAdmin && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(comment.id)}
                    className="hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>

              {/* Car Info */}
              {car && (
                <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                  <div className="w-16 h-12 rounded-lg overflow-hidden bg-muted">
                    <img src={car.image} alt={car.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <p className="text-sm">{car.name}</p>
                    <p className="text-xs text-muted-foreground">{car.brand} {car.model}</p>
                  </div>
                </div>
              )}

              {/* Rating */}
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-5 h-5 ${
                      star <= comment.rating
                        ? 'fill-yellow-500 text-yellow-500'
                        : 'text-muted-foreground'
                    }`}
                  />
                ))}
              </div>

              {/* Comment */}
              <p className="text-muted-foreground">{comment.comment}</p>

              {/* Admin Reply */}
              {comment.adminReply && (
                <div className="ml-8 p-4 rounded-xl bg-primary/5 border border-primary/10">
                  <div className="flex items-center gap-2 mb-2">
                    <Reply className="w-4 h-4 text-primary" />
                    <span className="text-sm text-primary">Admin Reply</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{comment.adminReply}</p>
                </div>
              )}

              {/* Reply Input (Admin only) */}
              {isAdmin && !comment.adminReply && (
                <div className="ml-8 flex gap-2">
                  <Input
                    placeholder="Write a reply..."
                    value={replyText[comment.id] || ''}
                    onChange={(e) =>
                      setReplyText({ ...replyText, [comment.id]: e.target.value })
                    }
                  />
                  <Button onClick={() => handleReply(comment.id)}>
                    <Reply className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </motion.div>
          );
        })}
      </div>

      {comments.length === 0 && (
        <div className="text-center py-12">
          <MessageSquare className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="mb-2">No reviews yet</h3>
          <p className="text-muted-foreground">Be the first to share your experience</p>
        </div>
      )}
    </div>
  );
}
